<!-- ПОЛОСА ЗАЯВКИ В ФУТЕРЕ -->
<!--noindex-->
<section class="home-8-trust">
        <div class="home-3-contact">
            <div class="container">
                <div class="row">
                <div class="home-3-contact-details home-8-contact-details clearfix">
                    <div class="col-md-9 no-padding-left">
                       <div class="Title-area">
                            <h3 style="color:#ffffff;">Не стесняйтесь задавать вопросы</h3>
                            <h2 style="color:#ffffff;">Закажите бесплатную консультацию</h2>
							<p style="color:#ffffff; font-size:16px;">Оставьте свои контакты, наш специалист свяжется с вами и проведет первичную консультацию. После чего вы сможете приехать в офис или направить документы (кредитный договор, договор страхования, карты помощи и т.д.) в электронном формате для получения полного правового анализа и рекомендаций по решению вашей проблемы. </p>
							<p style="color:#ffffff; font-size:16px;">Все консультации по делу бесплатные и ни к чему вас не обязывают. Оплата наших услуг осуществляется только после получения вами всех положенных выплат.</p>
                        </div>
                    </div>
                    <div class="col-md-3 no-padding-right">
                        <div class="h-8-contact-button">
                            <a href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class=""><button type="button" class="btn btn-default button">Заказать консультацию</button></a>
                        </div>
                    </div>
                </div> 
                </div> 
            </div>
        </div> 
</section>
<!--/noindex-->
<!-- ПОЛОСА ЗАЯВКИ В ФУТЕРЕ -->
    
<!-- ФУТЕР -->
<footer class="footer-area"> 
        <!-- верхняя полоса -->
        <div class="footer-head"> 
            <div class="container"> 
                <div class="row"> 
                    <div class="col-sm-4 col-md-4 col-xs-6"> 
                        <div class="f-h-content"> 
                            <i class="fa fa-phone-square hidden-xs" aria-hidden="true"></i>
                            <p class="h2"><a href="tel:+79930901634">+7 (993) 090-16-34</a></p>
							<p class="h2"><a href="tel:+78432032083">+7 (843) 203-20-83</a></p>
							<p class="h2"><a href="tel:+79376252083">+7 (937) 625-20-83</a></p>
						</div>
                    </div> 
                    <div class="col-sm-4 col-md-4 hidden-xs"> 
                        <div class="f-h-content"> 
                            <i class="fa fa-envelope" aria-hidden="true"></i>
                            <p class="h2"><a href="mailto:advokatkzn.com@gmail.com">advokatkzn.com@gmail.com</a></p>
							<p class="h2" style="color:#222222;">/</p>
							<p class="h2" style="color:#222222;">/</p>
                        </div> 
                    </div> 
                    <div class="col-sm-4 col-md-4 col-xs-6"> 
                        <div class="f-h-content"> 
                            <i class="fa fa-map hidden-xs"></i>
                            <p class="h2"><span class="hidden-xs">г.Казань, </span>ул.Петербургская <span class="hidden-xs">д.</span>74</p>
							<p class="h2">ИНН: 1659161957</p>
							<p class="h2">ОГРН: 1151690072313</p>
                        </div> 
                    </div>       
                </div> 
            </div> 
        </div>
        <!-- верхняя полоса -->
        
        <!-- нижняя полоса -->
        <div class="container">  
            <div class="row"> 
               <div class="footer-bottom f-v4-p-b-nm clearfix"> 
                    <div class="col-md-4 col-sm-6 no-padding-left"> 
                        <div class="f-bottom-left-text"> 
                            <p>ООО «ЮЦВА»  ©Все права защищены <span>2018-2026</span></p> 
                        </div> 
                    </div>
                    
                    <div class="col-md-4 col-sm-6 no-padding-left"> 
                        <div class="v-3-header-contact v-3-header-contact-social v-5-header-contact-social">
							<ul>
							   <li><a href="https://t.me/m/qVfUIGyHM2Ni" data-toggle="tooltip" data-placement="bottom" ><img src="<?php echo get_template_directory_uri();?>/images/telegram.webp" width="30" height="30" alt="телеграм"></a></li>
							   <li><a href="https://max.ru/u/f9LHodD0cOLVexKTk4GEzKABAcJNrC-qE9IAZ9E_hq5PncO5tlxwmB2QRl8" data-toggle="tooltip" data-placement="bottom" ><img src="/wp-content/uploads/2026/08/max.webp" width="30" height="30" alt="Max"></a></li>
							   <li><a href="https://vk.com/kazan_advokat" data-toggle="tooltip" data-placement="bottom" ><img src="<?php echo get_template_directory_uri();?>/images/vk.webp" width="30" height="30" alt="вконтакте"></a></li>
							   <li><a href="https://wa.me/79376252083?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!" data-toggle="tooltip" data-placement="bottom"><img src="<?php echo get_template_directory_uri();?>/images/whatsapp.webp" width="30" height="30" alt="ватсап"></a></li>
							</ul>
                        </div> 
                    </div> 
                    
                    <div class="col-md-4 col-sm-6 no-padding-right"> 
                        <div class="f-bottom-right-text"> 
                            <ul> 
                                <li><a href="/proverit-status-dela/">Статус дела</a></li>
                                <li><a href="/politika-konfidenczialnosti/">Конфиденциальность</a></li>
                                <li><a href="/politika-obrabotki-cookie/">Cookie</a></li>
                                <li><a href="/sitemap/">Карта сайта</a></li> 
                            </ul> 
                        </div> 
                    </div>
                    
                </div> 
            </div> 
        </div>
        <!-- нижняя полоса -->
    </footer> 
<!-- ФУТЕР -->


<!--noindex-->

<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();
   for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
   k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(98959947, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/98959947" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->

<!-- ЖИВОСАЙТ -->
        <script src="//code.jivo.ru/widget/CzsKJ7KgbX" async></script>
<!-- ЖИВОСАЙТ -->

<!--  МОДАЛЬНОЕ ОКНО -->
		<!-- noindex-->
			<div class="modal fade fform"  id="ModalOrderPackage01" tabindex="-1" role="dialog" aria-label="myModalLabel">
				    <div class="modal-dialog modal-sm">
				        <div class="modal-content ">
				            <div class="modal-header">
				                <button type="button" class="close" data-dismiss="modal"><span class="icon-cancel"><i class="fa fa-times"></i></span></button>
				            </div>
				            <div class="forma">
				                
				                <?php echo do_shortcode( '[contact-form-7 id="ea92099" title="popup"]' ); ?>
				        </div>
				    </div>
				</div>
				<script>document.addEventListener( 'wpcf7mailsent', function( event ) {jQuery('#formvopr').hide(); }, false );</script>
					<script>
	document.addEventListener( 'wpcf7mailsent', function () {
		setTimeout( function () {
			jQuery( '#ModalOrderPackage01' ).modal( 'hide' );
		}, 4000 );
	}, false );
	</script>
			</div> 
		<!--/noindex-->
<!-- / МОДАЛЬНОЕ ОКНО -->

    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/bootstrap.min.js"></script>
    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/owl.carousel.js"></script> 
    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/menuzord.js?v=1"></script> 
    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/countdown.js"></script> 
    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/jquery.counterup.js"></script>  
    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/waypoints.min.js"></script>  
    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/main.js"></script> 
    

    
    <?php wp_footer();?>
    
 
    
<!--/noindex-->
</body> 
</html> 
