<!DOCTYPE html>
<html lang="ru">


<head> 
    <meta charset="utf-8"> 
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
    <meta name="viewport" content="width=device-width, initial-scale=1"> 
    <title><?php wp_title();?></title>
    <?php wp_head();?>
    
    
    <link rel="shortcut icon" type="image/x-icon" href="favicon.ico" /> 
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/bootstrap.min.css"> 
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/font-awesome.min.css"> 
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/icon-stroke.css"> 
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/menuzord.css">  
    <?php if ( is_front_page() ) : ?>
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/revolution/css/settings.css">
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/revolution/css/layers.css">
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/revolution/css/navigation.css">
    <?php endif; ?>
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/owl.carousel.css">  
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/owl.theme.css"> 
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/main.css" rel="stylesheet"> 
    
    <script type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/jquery-1.11.3.min.js"></script> 
    
    <?php if ( is_front_page() ) : ?>
    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/revolution/js/jquery.themepunch.tools.min.js?rev=5.0"></script>
    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/revolution/js/jquery.themepunch.revolution.min.js?rev=5.0"></script>
    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
    <script defer type="text/javascript" src="<?php echo get_template_directory_uri();?>/js/rev-slider.js"></script>
    <?php endif; ?>
    
    
	<meta name="yandex-verification" content="00b04fecd327e1b8" />
	<meta name="google-site-verification" content="orIRO1fJz6Gd_yDOUi6AAivciKDUuz90bbHvn0asK7I" />
	<!-- Код: ВК49865 -->


<!-- Yandex Metrika Goals -->
<script>
  document.addEventListener('oprosMailsent', function () {
    // Событие сработает в случае успешной отправки формы из опросника
    ym(98959947, 'reachGoal', 'opros');
  });

  document.addEventListener('wpcf7mailsent', function () {
    // Событие сработает в случае успешной отправки формы из Contact Form 7
    ym(98959947, 'reachGoal', 'forma');
  });
</script>
<!-- End Yandex Metrika Goals -->
	
</head> 

	
<body> 

<!-- ХЭДЭР -->
    <header class="v-11-header-area header-12-area p-title-header-area  navbar-fixed-top"> 
        <div class="container custom-header"> 
            <div class="row"> 
                <div id="menuzord" class="menuzord p-title-menuzord"> 
                   <a href="/" class="menuzord-brand transparent-menuzord-brand">
					   <img src="<?php echo get_template_directory_uri();?>/images/logo2-new.png" alt="Логотип компании">
					   <span><img src="<?php echo get_template_directory_uri();?>/images/logo1-new.png"  alt="Логотип компании"></span>
					</a>
                   
                   <!-- контакты -->
                   <div class="header-contact">
                        <ul>
                           <li>
							<div class="v-3-header-contact v-3-header-contact-social v-5-header-contact-social">
								<ul>
								   <li><a href="https://t.me/m/qVfUIGyHM2Ni" data-toggle="tooltip" data-placement="bottom" ><img src="<?php echo get_template_directory_uri();?>/images/telegram.webp" width="30" height="30" alt="телеграм"></a></li>
								   <li><a href="https://max.ru/u/f9LHodD0cOLVexKTk4GEzKABAcJNrC-qE9IAZ9E_hq5PncO5tlxwmB2QRl8" data-toggle="tooltip" data-placement="bottom" ><img src="/wp-content/uploads/2026/08/max.webp" width="30" height="30" alt="Max"></a></li>
								   <li><a href="https://vk.com/kazan_advokat" data-toggle="tooltip" data-placement="bottom" ><img src="<?php echo get_template_directory_uri();?>/images/vk.webp" width="30" height="30" alt="вконтакте"></a></li>
								   <li><a href="https://wa.me/79376252083?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5!" data-toggle="tooltip" data-placement="bottom"><img src="<?php echo get_template_directory_uri();?>/images/whatsapp.webp" width="30" height="30" alt="ватсап"></a></li>
								</ul>
                        	</div> 
							</li>
							
							<li> 
							   <div class="tel"> 
								<a href="tel:+79930901634">+7 (993) 090-16-34</a> 
								<a href="tel:+78432032083">+7 (843) 203-20-83</a>
							   </div>
							</li>
							<li class="modal-but" style="padding: 0; ">
								<a style="font-weight: 600; background: #b9a356; padding: 5px 10px;  font-size: 14px; text-align: center;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="button">Бесплатная<br>консультация</a>
							</li>
                        </ul>
                   </div>                  
                   <!-- контакты -->
                   
                   <!-- меню -->
                   <ul class="menuzord-menu transparent-menuzord-menu transparent-menuzord-menu-3 menuzord-menu-bg"> 
                        <li><a href="/">Главная</a></li>
                         
                         <li><a href="/company/">О нас</a>
                            <ul class="dropdown">
                                <li><a href="/team/">Команда</a><li>  
                                <li><a href="/smi-o-nas/">СМИ о нас</a></li>
								<li><a href="/news/">Новости и статьи</a></li>
                            </ul>
                        </li>  
                        
                        <li><a href="/services/">Услуги</a>
                            <div class="megamenu megamenu-full-width megamenu-bg">
                                 <div class="megamenu-row">
                                    <div class="mega-item col4">
                                        <ul>
                                            <li><a href="/services/vozvrat-strahovki/">Возврат банковской страховки</a></li>
											<li><a href="/services/vozvrat-karty-pomoshhi-na-dorogah/ ">Возврат карты помощи</a></li>
                                            <li><a href="/services/otkaz-ot-opczionnogo-dogovora/">Отказ от опционного договора</a></li>
                                            <li><a href="/services/nezavisimye-garantii/">Отказ от независимой гарантии</a></li>
                                            <li><a href="/services/liczenzionnyj-dogovor/">Отказ от лицензионного договора</a></li>
											
                                        </ul>                   
                                    </div>
                                    <div class="mega-item col4">
                                        <ul>
											<li><a href="/services/abonentskie-dogovory/">Отказ от абонентских договоров</a></li>
                                            <li><a href="/services/poruchitelstvo/">Отказ от услуги поручительства</a></li>
                                            <li><a href="/services/karty-yuridicheskoj-i-mediczinskoj-pomoshhi/">Возврат карт юр и мед помощи</a></li>
                                            <li><a href="/services/sertifikaty-na-dopolnitelnye-uslugi/">Возврат сертификата на допуслуги</a></li>
                                            <li><a href="/services/servisnye-karty/">Отказ от сервисных карт</a></li>  
                                        </ul>                   
                                    </div>
                                    <div class="mega-item col4">
                                        <ul>
                                            <li><a href="/services/bezotzyvnaya-nezavisimaya-garantiya/">Отказ от «безотзывной» гарантии </a></li>
                                            <li><a href="/services/prodlennaya-garantiya/">Отказ от продлённой гарантии</a></li>
											<li><a href="/services/finansovaya-zashhita/">Отказ от «финансовой защиты»</a></li>
											<li><a href="/services/bankrotstvo/">Процедура банкротства</a></li>
                                        </ul>                    
                                    </div>                                           
                                </div>      
                            </div>
                        </li> 
                       
                       <li><a href="/czeny-i-sroki/">Цены и сроки</a></li>
					   <li><a href="/faq/">FAQ</a></li>
					   <li><a href="/instrukczii/">Инструкции</a></li>
                       <li><a href="/reviews/">Отзывы</a><li>  
                       <li><a href="/contacts/">Контакты</a></li>
                       <li><a href="/proverit-status-dela/">Статус дела</a></li>
                   </ul>
                   <!-- меню -->
                </div> 
            </div> 
        </div> 
    </header>
<!-- ХЭДЭР -->
