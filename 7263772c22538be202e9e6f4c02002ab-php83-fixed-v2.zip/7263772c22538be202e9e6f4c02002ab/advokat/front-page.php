<?php get_header();?>

<?php get_template_part( 'template-parts/slider-new' ); ?>
    
<!-- ЗАГОЛОВОК -->
    <section class="welcome-area">
        <div class="wellcome-asset">
            <div class="container text-center">
				<h1>Возврат страховки и допуслуг по автокредиту</h1>
            </div>
        </div> 
    </section> 
    
    <!-- подпись -->
        <div class="welcome-title-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="home-6-heading text-center">
                            <p>
                                <span>Возвращаем деньги за страховку и дополнительные услуги вроде «карт помощи» с <b>оплатой по факту</b> получения вами выплат. Заранее заботимся, о <b>сохранении % ставки</b> после отказа.</span> <br>
                                 &nbsp;&nbsp;• Бесплатно оценим ситуацию по телефону или по фото документов и назовём реальную сумму возврата.<br>
                                 &nbsp;&nbsp;• Все бумаги оформим за один визит в офис или дистанционно — ходить по инстанциям и в суд не придётся.<br>
                                 &nbsp;&nbsp;• Берёмся за дела и после «периода охлаждения» — даже если с покупки прошло больше года.<br>
                                 &nbsp;&nbsp;• Работаем с любыми банками, автосалонами и ассистанс-компаниями по всей России.<br>
                                 &nbsp;&nbsp;• В среднем клиенты возвращают <b>155 000 ₽</b> уже за вычетом оплаты наших услуг.<br><br>
                                <span>Вернём <b>всё, что положено по закону</b>, и подскажем, как <b>сократить кредитный платёж</b>. Звоните: <b><a href="tel:+78432032083">+7 (843) 203-20-83</a></b>, мы всё объясним!</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>   
    <!-- подпись -->
<!-- ЗАГОЛОВОК -->


<!--БЛОК ТАБОВ-->
<section class="home-6-story">
        
<div class="container">
    
<div class="Title-area">
    <span class="h3">За какие дела мы берёмся?</span>
    <h2>Направления работы</h2>
</div>
            <div class="row">
                <div class="home-4-story-tab">
                    <div class="col-sm-4 col-md-4 col-lg-4">

                      <!-- Nav tabs -->
                      <ul class="nav nav-tabs history-nav-tabs" role="tablist">
						<li role="presentation"class="active"><a href="#vbs" aria-controls="vbs" role="tab" data-toggle="tab">Возврат банковских страховок</a></li>
                        <li role="presentation"><a href="#kpnd" aria-controls="kpnd" role="tab" data-toggle="tab">Карты помощи на дорогах</a></li>
                        <li role="presentation"><a href="#od" aria-controls="od" role="tab" data-toggle="tab">Опционные договоры</a></li>
                        <li role="presentation"><a href="#ng" aria-controls="ng" role="tab" data-toggle="tab">Независимые гарантии</a></li>
                        <li role="presentation"><a href="#p" aria-controls="p" role="tab" data-toggle="tab">Поручительство</a></li>
                        <li role="presentation"><a href="#pg" aria-controls="pg" role="tab" data-toggle="tab">Продлённая гарантия</a></li>
						<li role="presentation"><a href="#ld" aria-controls="ld" role="tab" data-toggle="tab">Лицензионный договор</a></li>
                        <li role="presentation"><a href="#kymp" aria-controls="kymp" role="tab" data-toggle="tab">Карты юридической и медпомощи</a></li>
                        <li role="presentation"><a href="#sdu" aria-controls="sdu" role="tab" data-toggle="tab">Сертификаты на допуслуги</a></li>
                        <li role="presentation"><a href="#sk" aria-controls="sk" role="tab" data-toggle="tab">Сервисные карты</a></li>
                        <li role="presentation"><a href="#fz" aria-controls="fz" role="tab" data-toggle="tab">Финансовая защита</a></li>
						<li role="presentation"><a href="#bng" aria-controls="bng" role="tab" data-toggle="tab">Безотзывная независимая гарантия</a></li>
						<li role="presentation"><a href="#ad" aria-controls="ad" role="tab" data-toggle="tab">Абонентские договоры</a></li>
						<li role="presentation"><a href="#bank" aria-controls="bank" role="tab" data-toggle="tab">Банкротство</a></li>
                       
                      </ul>
                    </div>
                      <!-- Tab panes -->
                      <div class="tab-content">
						  
						  <div role="tabpanel" class="tab-pane fade in active" id="vbs">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
                                      <p><b><a href="/services/vozvrat-bankovskih-strahovok/">Возврат банковских страховок</a></b>. Прежде всего это индивидуальное или коллективное страхование жизни, КАСКО, GAP-страхование или ДМС. Также это может быть «коробочное» страхование имущества, здоровья от рядовых заболеваний, личной ответственности, от несчастных случаев, пожара, потопа и т. п.</p><p>Главная цель банка или автосалона в такой схеме — не забота о благе клиента, а увеличение суммы кредита и, конечно, дополнительный доход: переплаченные проценты для банка и комиссионное вознаграждение от «партнёров» для автосалона.</p><p>Мы всегда рекомендуем: «Если хотите быть застрахованным — страхуйтесь, но компанию и программу выбирайте сами и сами согласовывайте стоимость и условия». Даже если банк требует страховку как условие кредита, страховую компанию можно выбрать из тех, что соответствуют его требованиям. Зачастую же клиентов направляют не в самые «благонадёжные» компании, а в полис включают риски, которые почти никогда не наступают, и не включают обычные случаи: например, за сломанный палец вам никто не заплатит.</p>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-md-4 "> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>                                 
                            </div>                           
                        </div>
                        
                        
                        <div role="tabpanel" class="tab-pane fade" id="kpnd">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
                                        <p><b><a href="/services/karty-pomoshhi-na-dorogah/">Карты помощи на дорогах</a></b> — одна из самых распространённых дополнительных услуг, которые банки вместе с автосалонами продают по явно завышенным ценам. При этом для многих новых автомобилей аналогичную помощь бесплатно предоставляет производитель.</p><p>Даже если производитель таких услуг не оказывает или вы купили автомобиль с пробегом, всегда можно купить аналогичную карту или просто вызвать техпомощь на дороге, но уже по рыночной цене.</p><p>Если карта оплачена из кредита и указана в заявлении на кредит, в течение 14 календарных дней от неё можно отказаться в упрощённом порядке по закону о потребительском кредите. Позже отказаться можно в любой момент, пока договор действует: исполнитель вправе удержать только фактически понесённые расходы (ст. 32 Закона о защите прав потребителей).</p><p>У автосалонов обычно есть постоянные «партнёры» по таким услугам, и их названия периодически меняются. Например, в договорах клиентов «КАН-АВТО» нам встречались ООО «КАР Ассистанс», ООО «Сити Ассист», ООО «Автопомощник», ООО «Сервис Авто-9», а в договорах клиентов «ТрансТехСервиса» — компании группы «МИР»: ООО «МИР», ООО «Прогресс», ООО «Адванс», ООО «Адванс Ассист».</p>
                                        </div>
                                </div>
                                <div class="col-sm-4 col-md-4"> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>                                 
                            </div>                            
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="od">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
							            <p><b>Опционные договоры</b> — ещё одна разновидность дополнительных услуг, которые банки вместе с автосалонами продают при автокредитовании. Клиент платит «опционную премию» за право в будущем потребовать от компании услугу: помощь на дороге, выкуп автомобиля по остатку долга по кредиту и т. п. В наших делах часто встречаются связки: Локо-Банк — ООО «Авто-Защита», Экспобанк — ООО «Автоэкспресс», ВТБ — ООО «Гарант Контракт».</p><p>Такую форму используют как раз для того, чтобы отказывать клиентам в возврате денег: компании ссылаются на п. 3 ст. 429.3 ГК РФ, по которому при прекращении опционного договора платёж не возвращается. Но если опцион купил гражданин для личных нужд, применяется Закон о защите прав потребителей, и суды взыскивают деньги, если опционом не воспользовались. Мы работаем и с такими случаями!</p>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-md-4"> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>                                 
                            </div>                           
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="ng">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
                                           <p><b><a href="/services/nezavisimye-garantii/">Независимая гарантия</a></b> — ещё одна разновидность допуслуг, которые банки вместе с автосалонами продают при оформлении кредита. Её суть в том, что компания-гарант обязуется заплатить банку часть платежей по вашему кредиту, если наступят оговорённые обстоятельства: потеря работы, болезнь и т. п.</p><p>Такие гарантии обычно выдают постоянные компании-партнёры банков и автосалонов, например ООО «Прогресс» и ООО «КАР Ассистанс». При отказе они отвечают, что гарантия «уже выдана» и вернуть деньги нельзя.</p><p>Однако для гражданина договор с гарантом — это платная услуга, и если гарантией не воспользовались, плату во многих случаях удаётся взыскать. Мы берёмся и за такие дела.</p>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-md-4"> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>                                 
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="p">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
                                        <p><b>Поручительство</b> — ещё один вид дополнительных услуг, которые банки вместе с автосалонами продают доверчивым клиентам. Суть услуги в том, что за установленную договором плату поручитель обязуется погасить за клиента всю задолженность или оговорённое количество платежей, если тот станет неплатёжеспособен.</p><p>Но после этого поручитель вправе потребовать с клиента всё, что заплатил за него банку (ст. 365 ГК РФ), — то есть реальной защиты такая услуга не даёт. Банку она обеспечивает возврат кредита, а автосалон получает комиссию от компании-поручителя. У банков есть постоянные партнёры по таким услугам: например, у БыстроБанка — ООО «Брокер», у Росбанка — ООО «Юридический партнёр».</p><p>От договора с поручителем, как от любой платной услуги, можно отказаться и вернуть деньги за вычетом фактических расходов исполнителя (ст. 32 Закона о защите прав потребителей).</p>

                                    </div>
                                </div>
                                <div class="col-sm-4 col-md-4"> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>                                 
                            </div>                            
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="pg">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
                                        <p><b><a href="/services/prodlennaya-garantiya/">Продлённая гарантия</a></b> — довольно интересная разновидность допуслуг, которые навязывают банки или автосалоны при покупке автомобилей. Суть услуги в том, что при наступлении оговорённых обстоятельств компания обязуется оплатить ремонт или сервисное обслуживание автомобиля клиента.</p><p>Обратите внимание: пока действует заводская гарантия, перечень таких случаев часто повторяет обязательства завода-изготовителя, которые тот и так исполняет бесплатно.</p><p>Эти услуги оказывают постоянные партнёры банков и автосалонов: например, у Росбанка — ООО «Гарант Контракт», у «ТрансТехСервиса» — ООО «Прогресс».</p><p>Продлённая гарантия — это договор оказания услуг, поэтому от него можно отказаться в любой момент и вернуть деньги за вычетом фактических расходов исполнителя (ст. 32 Закона о защите прав потребителей). Если компания отказывает, наша компания знает, как работать и с такими случаями.</p>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-md-4"> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>                                
                            </div>                          
                        </div>
						  <div role="tabpanel" class="tab-pane fade" id="ld">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
                                        <p><b>Лицензионный договор</b> — ещё одна разновидность ненужных услуг, которые навязывают банки совместно с автосалонами. По такому договору обладатель исключительного права на результат интеллектуальной деятельности или на средство индивидуализации предоставляет или обязуется предоставить другой стороне право его использования (ст. 1235 ГК РФ).</p><p>Фактически за указанную в договоре плату клиент получает доступ в личный кабинет или логин и пароль от какого-то сервиса. Такую форму выбирают, чтобы сослаться на правила об интеллектуальной собственности и не возвращать деньги. Но если по сути клиент покупал помощь на дороге или консультации, суды нередко признают договор оказанием услуг и применяют Закон о защите прав потребителей.</p><p>У банков есть постоянные партнёры по таким продуктам, например: у БыстроБанка — ООО «Брокер»; у ВТБ и Росбанка — ООО «Гарант Контракт», ООО «Д.С. Дистрибьютор», ООО «Д.С.Авто», ООО «Сити Ассист», ООО «Драйв Ассист», ООО «Юридический партнёр».</p>
                                    </div>
                                </div>
                               <div class="col-sm-4 col-md-4"> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>                                
                            </div>                           
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="kymp">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
                                       <p><b>Карты юридической и медицинской помощи</b> — очередная разновидность услуг, которые банки и автосалоны навязывают при покупке автомобиля по сильно завышенным ценам.</p><p>По такому договору клиент получает право обратиться за устной или письменной консультацией в некую юридическую или медицинскую организацию. Конечно, о должной компетенции и профессионализме таких компаний говорить не приходится.</p><p>Обычно это абонентский договор или договор оказания услуг, поэтому отказаться от него можно в любой момент и вернуть деньги за неиспользованный период. Если карта оплачена из кредита и указана в заявлении на кредит, первые 14 календарных дней действует упрощённый порядок возврата. Такие карты часто продают те же партнёры автосалонов, что и карты помощи на дорогах.</p>
                                    </div>
                                </div>
                               <div class="col-sm-4 col-md-4"> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>                                
                            </div>                           
                        </div>
                         <div role="tabpanel" class="tab-pane fade" id="sdu">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
                                      <p><b>Сертификаты на дополнительные услуги</b> — очередной вид услуг, которые навязывают в автосалонах при оформлении кредита на машину. Цена такого сертификата высокая, хотя многое из его перечня часто можно бесплатно получить в рамках заводской гарантии автомобиля.</p><p>Важно понимать, что «сертификат» — лишь оформление. За ним может стоять абонентский договор, опцион, лицензия или независимая гарантия, и от этого зависит, на какие нормы ссылаться и сколько можно вернуть.</p><p>Если сертификат оплачен из кредита и указан в заявлении на кредит, в течение 14 календарных дней от него можно отказаться в упрощённом порядке. Позже отказаться можно в любой момент, пока договор действует.</p>                                                            </div>
                                </div>
                               <div class="col-sm-4 col-md-4"> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>                               
                            </div>                           
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="sk">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
                                       <p><b>Сервисные карты</b> — ещё одна разновидность дополнительных услуг, в большинстве случаев ненужных, которые часто навязывают банки и автосалоны по весьма завышенным ценам. Часть услуг из такой карты в период гарантии и так бесплатно предоставляет завод-изготовитель.</p><p>От сервисной карты можно отказаться в любой момент, пока договор действует, и вернуть деньги за вычетом фактических расходов исполнителя. Если карту оформили как абонентский договор, плату взыскивают пропорционально оставшемуся сроку.</p>
									</div>
                                </div>
                                <div class="col-sm-4 col-md-4"> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>                               
                            </div>                           
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="fz">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
                                        <p><b>Финансовая защита</b> — очередной вид допуслуг, которые навязывают клиентам в автосалоне или банке недобросовестные менеджеры. Чаще всего суть в том, что если заёмщик по каким-то причинам не может вносить платежи по кредиту, он вправе потребовать, чтобы компания выкупила автомобиль по остатку долга. Но под этим же названием продают и страхование GAP, и независимую гарантию.</p><p>Порядок возврата зависит от того, что именно вы подписали. Если это страховка, оформленная вместе с кредитом, от неё можно отказаться в течение 30 календарных дней и вернуть премию полностью, если не было страхового случая. Если это опцион или гарантия, действуют Закон о защите прав потребителей и судебная практика.</p><p>Этот вид допуслуг считается «сложным»: его создают с расчётом, чтобы клиент не смог вернуть деньги после обычного заявления об отказе. Однако наша компания берётся за такие дела и успешно их выигрывает!</p>
                                    </div>
                                </div>
                               <div class="col-sm-4 col-md-4"> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>                                
                            </div>                           
                        </div>
                        
						  <div role="tabpanel" class="tab-pane fade" id="bng">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
                                      <p><b><a href="/services/bezotzyvnaya-nezavisimaya-garantiya/">Безотзывная независимая гарантия</a></b> — ещё одна весьма дорогая дополнительная услуга, которую продают банки или автосалоны. Смысл её в том, что гарант (исполнитель) по просьбе клиента принимает на себя обязательство уплатить третьему лицу (банку) определённую сумму в соответствии с условиями данного гарантом обязательства (ст. 368 ГК РФ).</p><p>Иными словами, если клиент становится неплатёжеспособен, его платежи по кредиту частично или полностью оплачивает гарант — за установленную договором плату.</p><p>Но не всё так просто: заплатив банку, гарант по общему правилу вправе потребовать эти деньги с клиента (ст. 379 ГК РФ). Выгода компании-исполнителя очевидна: она получает крупную плату, а выплаченное банку потом взыскивает с заёмщика.</p><p>«Безотзывность» (ст. 371 ГК РФ) означает лишь то, что гарант не может отозвать гарантию перед банком. Права клиента как потребителя отказаться от договора с гарантом она не отменяет, и позицию «гарантия выдана — деньги не возвращаются» нередко удаётся оспорить в суде.</p>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-md-4"> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>                                 
                            </div>                           
                        </div>
                        
                        
                        
                        
						<div role="tabpanel" class="tab-pane fade" id="ad">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
                                      <p><b><a href="/services/abonentskie-dogovory/">Абонентские договоры</a></b> — ещё одна довольно хитрая схема продажи дополнительных услуг в автосалонах и банках по чрезмерно завышенной цене. Многое из того, что обещают по такому договору, для новых автомобилей часто бесплатно предоставляет завод-изготовитель.</p><p>По абонентскому договору (ст. 429.4 ГК РФ) клиент платит за право получать услуги в течение срока, даже если ими не пользуется. Исполнители ссылаются на это, чтобы ничего не возвращать.</p><p>Однако потребитель вправе отказаться от договора в любой момент (ст. 32 Закона о защите прав потребителей), и суды взыскивают абонентскую плату пропорционально неистёкшему сроку договора. Чем раньше подан отказ, тем больше вернётся.</p>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-md-4"> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>                                
                            </div>                           
                        </div>
                        
                        <div role="tabpanel" class="tab-pane fade" id="bank">
                            <div class="history-right-content">
                                <div class="col-sm-4 col-md-4 no-padding-right">
                                    <div class="history-right-content-text">
                                      <p><b>Банкротство</b> — это реабилитационная процедура, направленная на скорейшее восстановление платёжеспособности и уровня потребления граждан, что выгодно как экономике страны в целом, так и отдельному человеку.</p><p>Часто стоимость процедуры оказывается ниже суммы оставшихся платежей по кредитам. При судебном банкротстве начисление неустоек и процентов по долгам прекращается с даты, когда суд признает заявление обоснованным и введёт процедуру, а при внесудебном — со дня включения сведений о должнике в Единый федеральный реестр сведений о банкротстве. До этого момента обязательства перед кредиторами сохраняются.</p><p>Для граждан, в том числе индивидуальных предпринимателей, процедура банкротства доступна двумя способами: через арбитражный суд и во внесудебном порядке через МФЦ. Внесудебное банкротство бесплатно и возможно при долге от 25 000 до 1 000 000 ₽, если приставы окончили исполнительное производство из-за отсутствия имущества. В обоих случаях размер долга определяется на дату подачи заявления.</p>
                                    </div>
                                </div>
                                
                                <div class="col-sm-4 col-md-4"> 
                                    <div class="progress-left-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/4fon.webp" class="img-responsive" alt="">
										<span><i class="fa fa-shield"></i></span>
										<div style="margin-top: -30%;" class="text-center">
							   				<button type="button" class="button"><a style="margin:0;" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Заказать консультацию <i class="fa fa-long-arrow-right"></i></a></button>
										</div>
                                    </div>  
                                </div>
                                
                                
                            </div>                           
                        </div> 
						
                    </div>                   
                </div>
            </div>
        </div>
    </section> 
<!--БЛОК ТАБОВ-->

<?php get_template_part( 'template-parts/banki' ); ?>
<?php get_template_part( 'template-parts/zahvat2' ); ?>
<?php get_template_part( 'template-parts/team' ); ?>
<?php get_template_part( 'template-parts/news' ); ?>
<?php get_template_part( 'template-parts/dela' ); ?>

<!-- СЧЁТЧИКИ-->
<!--noindex-->
    <section class="fun-fact-area">
        <div class="welcome-title-area">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12">
                        <div class="Title-area contact-title h-5-title">
                            <span class="h3">Немного фактов</span>
                            <h2>Мы в цифрах</h2>
                            <p>За годы работы мы добились результатов, которые можно выразить в цифрах.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div> 

        
        <div class="countdown h-5-countdown-icon">
            <div class="container">
                <div class="row no-margin">
                    <div class="countdown-inner h-5-countdown-inner clearfix">
                        
                        <div class="col-xs-12 col-sm-6 col-md-4 no-padding">
                            <div class="countdown-content h-5-countdown-content">
                                <h2><span class="counter">5000</span>+ </h2>
                                <p>Довольных клиентов</p>
                            </div>
                            <div class="countdown-icon h-5-countdown-icon">
                                <i class="icon icon-Users"></i>
                            </div>
                        </div>
                        
                        <div class="col-xs-12 hidden-sm col-md-4 no-padding">
                            <div class="countdown-content h-5-countdown-content">
                                <h2>на <span class="counter">256978127</span> ₽</h2>
                                <p>Нами возвращено за страховки и допуслуги</p>
                            </div>
                            <div class="countdown-icon h-5-countdown-icon">
                                <i class="icon icon-Column"></i>
                            </div>
                        </div>
                        
                        <div class="col-xs-12 col-sm-6 col-md-4 no-padding">
                            <div class="countdown-content h-5-countdown-content">
                                <h2><span class="counter">99</span>%</h2>
                                <p>Выигранных дел</p>
                            </div>
                            <div class="countdown-icon h-5-countdown-icon">
                                <i class="icon icon-Briefcase"></i>
                            </div>
                        </div>
                        

                    </div>
                </div> 
            </div>
        </div> 
    </section>
    <!--/noindex-->
<!-- СЧЁТЧИКИ-->

<?php get_template_part( 'template-parts/strahi' ); ?>
<?php get_template_part( 'template-parts/otziv' ); ?>
<?php get_template_part( 'template-parts/tarif' ); ?>

<!-- ТЕКСТОВЫЙ БЛОК 2 -->
<section class="blog-section black-bg-4 sp-two pt-5">
	<div class="container">
		<div class="Title-area">
		<span class="h3">Работаем по всей России</span>
		<h2>В чём суть нашей работы?</h2>
			
		</div>
		<div class="row">
			<div class="col-lg-6 col-sm-12">
				<div class="prokrutka">
					<div class="text">
						<article>
        				 <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
						<?php the_content(); ?>
						<?php endwhile; ?><?php endif; ?>
   					   </article>
					</div>
				</div>
			</div>
			<div class="col-lg-6 hidden-sm rimg">
				<img src="<?php echo get_template_directory_uri();?>/images/u12.webp" alt="возврат страховки по кредиту">
			</div>
		</div>
	</div>
</section>
<!-- ТЕКСТОВЫЙ БЛОК 2 -->

<?php get_footer();?>