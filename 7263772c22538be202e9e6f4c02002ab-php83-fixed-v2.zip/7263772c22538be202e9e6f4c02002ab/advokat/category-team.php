<?php /* Template Name: Команда*/ get_header();?> 
<?php get_template_part( 'template-parts/breadcrumb-cat' ); ?>
    <section class="our-team-area attorney-1"> 
        <div class="team-member-area">
            <div class="container">
                <div class="row">
                    <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="team-description">
                            <div class="team-content">
                                <div class="team-img attorney-team-img">
                                    <a href="#"><img src="<?php if ( has_post_thumbnail()) { $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full'); echo $large_image_url[0]; } ?>"  alt="<?php the_title(); ?>"></a>
                                    <div class="attorney-content-default text-center">
                                         <h2><a href="#"><?php the_title(); ?></a></h2>
                                        <p><?php the_field('doljnost'); ?></p>
                                    </div>
                                </div>
                               
									<div class="about-attorney-member text-center">
                                    <div class="attorney-content-default-hover">
                                        <h2><a href="#"><?php the_title(); ?></a></h2>
                                        <p><?php the_field('doljnost'); ?></p>
                                    </div>
                                    <div class="social-content-box attorney-team-social">
										<a href="#"><p><?php the_field('sfera'); ?></p></a>
                                    </div>
									</div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?> 
                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-md-12 blog-pagination text-center clearfix">
                        <div class="pagination-wrapper">
                            <?php
                             if ( function_exists('wp_bootstrap_pagination') )
                             wp_bootstrap_pagination();
                           ?>
                        </div>                                     
                    </div>
                </div>                
            </div>
        </div>       
    </section>  
<?php get_footer();?>
