<?php /* Template Name: Услуги*/ get_header();?> 
<?php get_template_part( 'template-parts/breadcrumb-cat' ); ?>
    <section class="testimonial-area home-2-testimonial-area">
        <div class="testimonial-content-area">
            <div class="container">
                <div class="row">
                    <div class="t-b-content-area blog-content-area clearfix">
                        <div class="col-md-12 no-padding blog-custom-padding">
                                <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                                <div class="col-md-3 col-sm-6">
                                    <div class="t-b-details t-b-single tb-grid">
                                        <div class="t-b-img">
                                            <a href="<?php the_permalink();?>"><img src="<?php if ( has_post_thumbnail()) { $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full'); echo $large_image_url[0]; } ?>"  alt="<?php the_title(); ?>"></a>
                                        </div> 
                                        <h2><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h2>
                                        <p><?php the_field('small-services'); ?></p>
                                    </div>
                                </div>
                                <?php endwhile; ?> 
                                <?php endif; ?>
                                
                                <div class="row"> 
                                    <div class="col-md-12 blog-pagination text-center clearfix">
                                         <div class="pagination-wrapper">
                                            <?php
                                            if ( function_exists('wp_bootstrap_pagination') )
                                            wp_bootstrap_pagination();
                                            ?>
                                        </div>                                    
                                    </div>
                                </div>    
                        </div>    
                    </div>
                </div>
            </div>  
            
            
            <?php get_template_part( 'template-parts/zahvat' ); ?>
            
        </div>       
    </section>
<?php get_footer();?>

