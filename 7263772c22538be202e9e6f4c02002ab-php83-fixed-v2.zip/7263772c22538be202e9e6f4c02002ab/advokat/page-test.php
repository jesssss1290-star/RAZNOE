<?php get_header();?>

<?php get_template_part( 'template-parts/slider-new' ); ?>

    <section class="testimonial-area">
        <div class="testimonial-content-area">
            <div class="container">
                <div class="row">
                    <div class="t-b-content-area blog-content-area clearfix">
                        <div class="col-md-12 col-sm-12 no-padding blog-custom-padding">
                            <div class="col-md-12 col-sm-12">
                                    <h2><?php the_title(); ?></h2>
                                    <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                                    <?php the_content(); ?>
                                    <?php endwhile; ?><?php endif; ?>
                                </div>  
                            </div> 
                        </div> 
                    </div>
                </div>
            </div>
    </section>
    
<?php get_footer();?> 