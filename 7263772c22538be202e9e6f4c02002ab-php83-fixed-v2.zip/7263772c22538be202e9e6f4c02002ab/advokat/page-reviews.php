<?php get_header();?>
 <?php get_template_part( 'template-parts/breadcrumbs' ); ?>
 
<!-- КОНТЕНТ -->
<section class="testimonial-area">
        <div class="testimonial-content-area">
            <div class="container">
                <div class="row">
                    <div class="t-b-content-area blog-content-area clearfix">
                        <div class="col-md-12 col-sm-12 no-padding blog-custom-padding">
                            <div class="col-md-12 col-sm-12">
                                    <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                                    <?php the_content(); ?>
                                    <?php endwhile; ?><?php endif; ?>
                                </div>  
                            </div> 
                        </div> 
                    </div>
                </div>
            </div>
    </section>
<!-- КОНТЕНТ -->

<!-- ПЛАГИН ОТЗЫВОВ -->
<section>
	<div class="container">
	<script src="https://res.smartwidgets.ru/app.js" defer></script>
<div class="sw-app" data-app="23652bd26c9ba1c8b977701bbc568371"></div>
	</div>
</section>

<hr>

<section>
	<div class="container">
		<div class="col-lg-6 col-sm-12">
			<div style="width:560px;height:800px;overflow:hidden;position:relative;"><iframe style="width:100%;height:100%;border:1px solid #e6e6e6;border-radius:8px;box-sizing:border-box" src="https://yandex.ru/maps-reviews-widget/220101019774?comments"></iframe><a href="https://yandex.ru/maps/org/vash_advokat/220101019774/" target="_blank" style="box-sizing:border-box;text-decoration:none;color:#b3b3b3;font-size:10px;font-family:YS Text,sans-serif;padding:0 20px;position:absolute;bottom:8px;width:100%;text-align:center;left:0;overflow:hidden;text-overflow:ellipsis;display:block;max-height:14px;white-space:nowrap;padding:0 16px;box-sizing:border-box">Ваш адвокат на карте Казани — Яндекс Карты</a></div>
		</div>
		<div class="col-lg-6 col-sm-12">
			<script src="https://res.smartwidgets.ru/app.js" defer></script>
            <div class="sw-app" data-app="d0a1acafae9c4133110ecde1042d4035"></div>
		</div>
    </div>
</section>
<!-- ПЛАГИН ОТЗЫВОВ -->

<?php get_template_part( 'template-parts/zahvat2' ); ?>
<?php get_footer();?>