<?php get_header();?> 
    <section style="padding:100px 0 50px 0;" class="page-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="">
                        <div class="page-title-content text-center">
                          <h1>Возврат денег от <?php single_cat_title(); ?></h1>
							
                        </div>
                        <div class="breadcrumbs text-center">
                          <?php
                               if ( function_exists('yoast_breadcrumb') ) {
                               yoast_breadcrumb('<span id="breadcrumbs">','</span>'); }?>                       
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> 
     <section class="testimonial-area home-2-testimonial-area desktop">
        <div class="testimonial-content-area">
            <div class="container">
				<div class="row">
					 <div class="col-sm-8 col-md-8 no-padding">
					<div class="t-b-content-area blog-content-area clearfix">
                        <div class="no-padding">
                            <div class="t-b-details blog-tb-details">
                             <?php echo category_description(); ?>
                            <hr>
								<div class="row kontur">		
									<h4><i><b>Автор статьи:</b></i></h4>
											<div class="col-md-4 col-sm-4 col-xs-4">
                        								<div class="t-b-details t-b-single">
                                 							<div class="t-b-img">
                                          						<img src="<?php the_field('img'); ?>"  alt="юрист">
                                  							</div>
                          								</div>
                   									</div>
												   <div class="col-md-8 col-sm-8 col-xs-8">
														   <div class="t-b-single">
																	<h2><b><?php the_field('fio'); ?></b></h2>
																	<p><b>Юрист</b></p>
																	<p><?php the_field('sfera'); ?></p>
														   </div>
												 </div>
								</div>
                            </div> 
						</div>
					</div>
					</div>
					<div class="col-md-4 col-sm-4 l-s-r-l-out">
					   <div class="right-sidebar">
						<div class="sidebar-category sidebar-inner">
							<!--<h2>Поиск</h2>
                        <div class="search-bar">
                            <form action="#">
                                <input type="text" value="" class="sidebar-input-text" placeholder="Поиск ...">
                                <input type="submit" class="sidebar-input-submit"  value="">
                                <i class="fa fa-search"></i>
                            </form>
                        </div> <!-- end search-bar -->
                       <h2>Юридическое обоснование</h2>
							<?php echo get_field('baza'); ?>
                            <h2>Выигранные дела</h2>
							<div class="row">
                     	 <?php $my_posts = get_posts('numberposts=44&category=12&orderby=date'); foreach ($my_posts as $post) :setup_postdata($post); ?>
                                <div class="col-md-12 col-sm-12">
                                    <div class="t-b-single">
                                        <h2><a href="<?php the_permalink();?>"><i class="fa fa-balance-scale" aria-hidden="true"></i>&ensp;&ensp;<?php the_title(); ?></a></h2>
										<div class="t-b-comment">
                                    		<p><i class="fa fa-pencil-square" aria-hidden="true"></i> Опубликовано: <span><?php the_date();?></span></p>
                                		</div>
                                        <p><?php kama_excerpt("maxchar=250"); ?> </p>
                                    </div>
                                </div>
                           	<?php wp_reset_postdata();?>
                            <?php endforeach; ?>   
							</div> 
							</div>
						</div>
						<?php dynamic_sidebar( 'right-side' ); ?>
					</div>
				</div>
               </div>     
           </div> 
    </section> 
 <section class="testimonial-area home-2-testimonial-area mobile">
        <div class="testimonial-content-area">
            <div class="container">
			<div class="shop-single-tab">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs s-tab-head" role="tablist">
                            <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Описание</a></li>
							<li role="presentation"><a href="#pravo" aria-controls="pravo" role="tab" data-toggle="tab">Правовая база</a></li>
                            <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Выигранные дела</a></li>
							<li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Отзывы</a></li>
							
                        </ul>

                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="home">
                                <div class="shop-tab-content">
                        			<div class="t-b-content-area blog-content-area clearfix">
                        				<div class="no-padding">
                            				<div class="t-b-details blog-tb-details blog-tb-single-details">
                             				<?php echo category_description(); ?>
												<hr>
                            				</div> 
										</div>
									</div>
                  				</div>
               				</div>
							<div role="tabpanel" class="tab-pane" id="pravo">
                                <div class="shop-tab-content">							
                              <div class="row">
									
								
							<?php $my_posts = get_posts('numberposts=10&category=7&orderby=date'); foreach ($my_posts as $post) :setup_postdata($post); ?>
							
								 
                               
                                <div class="col-md-12 col-sm-12">
                                    <div class="t-b-details blog-tb-details blog-tb-single-details">
                                    <ul>
										<li>
											<a href="<?php the_permalink();?>"><?php the_title(); ?></a>
											<div class="t-b-comment">
                                    			<p><i class="fa fa-pencil-square" aria-hidden="true"></i> Опубликовано: <span><?php the_date();?></span></p>
                                			</div>
										</li>
									</ul>
										
                                    </div>
                                </div>
                           
								<?php wp_reset_postdata();?>
                            <?php endforeach; ?>
								  <?php $my_posts = get_posts('numberposts=10&category=8&orderby=date'); foreach ($my_posts as $post) :setup_postdata($post); ?>
                                <div class="col-md-12 col-sm-12">
                                    <div class="t-b-details blog-tb-details blog-tb-single-details">
                                    <ul>
										<li>
											<a href="<?php the_permalink();?>"><?php the_title(); ?></a>
											<div class="t-b-comment">
                                    			<p><i class="fa fa-pencil-square" aria-hidden="true"></i> Опубликовано: <span><?php the_date();?></span></p>
                                			</div>
										</li>
									</ul>
                                    </div>
                                </div>
                           
								<?php wp_reset_postdata();?>
                            <?php endforeach; ?>
									</div>
								
                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane" id="profile">
                                <div role="tabpanel" class="tab-pane active" id="home">
                                <div class="shop-tab-content">
                         <div class="row kontur">
                     	 <?php $my_posts = get_posts('numberposts=44&category=12&orderby=date'); foreach ($my_posts as $post) :setup_postdata($post); ?>
                             
                               <div class="col-md-2 col-sm-2 col-xs-2">
                                    <div class="t-b-details t-b-single">
                                        <div class="t-b-img">
                                             <a href="<?php the_permalink();?>"><img src="/wp-content/uploads/2024/10/kiy2.jpg"  alt="выигранное дело"></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-10 col-sm-10 col-xs-10">
                                    <div class="t-b-single">
                                        <h2><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h2>
										<div class="t-b-comment">
                                    		<p><i class="fa fa-pencil-square" aria-hidden="true"></i> Опубликовано: <span><?php the_date();?></span></p>
                                		</div>
                                        <p><?php kama_excerpt("maxchar=100"); ?> </p>
                                    </div>
                                </div>

                           	<?php wp_reset_postdata();?>
                            <?php endforeach; ?>   
							</div> 
                                </div>
                            	</div>
                            </div>  
							<div role="tabpanel" class="tab-pane" id="messages">
                                <div class="shop-tab-content">
                                    <script src="https://res.smartwidgets.ru/app.js" defer></script>
									<div class="sw-app" data-app="23652bd26c9ba1c8b977701bbc568371"></div>
                                </div>
                            </div>
							
							
                        </div>                    
                    </div> 
			</div>
	 </div>
</section>
<?php get_template_part( 'template-parts/team' ); ?>
<?php get_template_part( 'template-parts/otziv' ); ?>
<?php get_template_part( 'template-parts/zahvat' ); ?>
<?php get_footer();?> 