<?php
/*
 * Template Name: Услуга ручная
 * Template Post Type: post
 */
?>
<?php get_header();?>
<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
    <section class="feature-typo h-f-typo"> 
        <div class="container">
            <div class="row">                 
                <div class="col-md-8"> 
					<div class="shop-single-review clearfix"> 
                        <div class="shop-review-content">  
                            <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                            <?php the_content(); ?>
                            <?php endwhile; ?><?php endif; ?>
                        </div>  
                    </div> 				 
                </div> 
				 <div class="col-md-4"> 
					<img src="<?php if ( has_post_thumbnail()) { $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full'); echo $large_image_url[0]; } ?>"  alt="<?php the_title(); ?>">
                    <?php the_field('baza'); ?>
					 <div class="shop-single-review clearfix"> </div> 
                </div> 
            </div> 
        </div>                       
    </section> 
                    
		<section class="practice-area home-2-practice-area type-1-bg"> 
        <div class="container">
            <div class="row">
                <div class="h-2-practice-content clearfix">
                  	<div class="col-xs-12 col-sm-10">
                        <div class="Title-area">
                            <h2>Возможности возврата</h2>
                        </div>
                   </div>
                   <?php the_field('sroky'); ?>
                </div> 
            </div> 
        </div>        
    </section>
<?php get_template_part( 'template-parts/strahi' ); ?>
<?php get_template_part( 'template-parts/news' ); ?>
<?php get_template_part( 'template-parts/zahvat2' ); ?>
<?php get_template_part( 'template-parts/team' ); ?>
<?php get_template_part( 'template-parts/other' ); ?>
    

    <?php get_footer();?> 