<?php
/*
 * Template Name: Юрист
 * Template Post Type: post
 */
?>
<?php get_header();?>
<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
    <section class="attorney-single-area">
        <div class="testimonial-content-area">
            <div class="container">
                <div class="row">
                    <div class="attorney-single-content">
                        <div class="col-md-4 col-sm-4">
                            <div class="team-description">
                                <div class="team-content">
                                    <div class="team-img">
                                        <img src="<?php if ( has_post_thumbnail()) { $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full'); echo $large_image_url[0]; } ?>"  alt="">
                                    </div>
                                </div>
                                <div class="member-name text-center">
                                    <h2><?php the_title(); ?></h2>
                                    <p><?php the_field('doljnost'); ?></p>
                                    <span></span>
                                </div>
                            </div>
                            <div class="attorney-single-btn">
								<a href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Записаться на консультацию</a>
                            </div> 
                        </div>
                        <div class="col-md-8 col-sm-8 blog-custom-padding">
							 <p><?php the_field('sfera'); ?></p>
                            <!--<div class="attorney-introduction">
							<?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                            <?php the_content(); ?>
                            <?php endwhile; ?><?php endif; ?>
                                <h2>Достижения</h2>
								<?php the_field('schet'); ?>
                            </div>-->
                        </div>                                                  
                    </div>
                </div>
            </div>       
        </div>       
    </section>
<?php get_template_part( 'template-parts/team' ); ?>
<?php get_template_part( 'template-parts/zahvat2' ); ?>
    <?php get_footer();?> 