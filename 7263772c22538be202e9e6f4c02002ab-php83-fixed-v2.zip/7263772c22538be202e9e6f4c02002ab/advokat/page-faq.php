<?php get_header();?>
<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
    
    <!-- ТЕКСТОВЫЙ КОНТЕНТ -->
        <div class="container"> 
            <div class="row">                 
                <div class="col-md-12"> 
                    <div class="shop-single-review clearfix"> 
                        <div class="shop-review-content">  
                            <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                               <?php the_content(); ?>
                            <?php endwhile; ?><?php endif; ?>
                        </div>  
                    </div> 
                </div> 
            </div> 
        </div> 
    <!-- ТЕКСТОВЫЙ КОНТЕНТ -->
                    
    
    <!-- ВОПРОСЫ И ОТВЕТЫ -->
    <section class="practice-area home-2-practice-area type-1-bg"> 
        <div class="container">
            <div class="row">
                <div class="h-2-practice-content clearfix">
                    <div class="col-sm-12 col-md-12">
                       <div class="accordion-single-page">
                            <div class="clearfix">
                                <div class="single-accordion-content">
                                    <div class="faq-accordion">
                                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                            
                   
<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading1">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="false" aria-controls="collapse1"><i class="fa fa-question" aria-hidden="true"></i>Как понять, что услуга была навязана?</a>
      </h4>
    </div>
    <div id="collapse1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading1">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>Сравните сумму кредита в договоре (или потраченных наличных) со стоимостью автомобиля, которую вам озвучивали менеджеры. Если суммы различаются — возможно, вам навязали дополнительные услуги. Отправьте нам документы на бесплатный анализ — определим, что можно вернуть.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading2">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse2" aria-expanded="false" aria-controls="collapse2"><i class="fa fa-question" aria-hidden="true"></i>Как проходит работа с вами?</a>
      </h4>
    </div>
    <div id="collapse2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading2">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>1. Вы отправляете нам кредитные документы.</p>
                <p>2. Мы проводим бесплатный анализ и сообщаем, какую сумму можно вернуть.</p>
                <p>3. При согласии предоставляете паспорт, реквизиты счёта и пару документов из банка.</p>
                <p>4. Заключаем договор — вы подписываете его дома и отправляете скан.</p>
                <p>5. Мы ведём дело самостоятельно. Никуда ездить не нужно. Вы просто ждёте поступления денег на счёт.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading3">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse3" aria-expanded="false" aria-controls="collapse3"><i class="fa fa-question" aria-hidden="true"></i>Как проходит процесс возврата?</a>
      </h4>
    </div>
    <div id="collapse3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>Процесс строго последовательный. Сначала претензионный порядок, затем досудебное урегулирование, при необходимости — судебное разбирательство.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading4">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse4" aria-expanded="false" aria-controls="collapse4"><i class="fa fa-question" aria-hidden="true"></i>Какие сроки ведения дела?</a>
      </h4>
    </div>
    <div id="collapse4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading4">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>Сроки зависят от способа оформления кредита и выбранного порядка урегулирования. Подробности — на странице <a href="/czeny-i-sroki/">Цены и сроки.</a> Мы делаем всё возможное для ускорения процесса.</p>  
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading5">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse5" aria-expanded="false" aria-controls="collapse5"><i class="fa fa-question" aria-hidden="true"></i>Когда именно я получу свои деньги?</a>
      </h4>
    </div>
    <div id="collapse5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading5">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>Мы работаем по принципу «гонорар успеха» — получаем вознаграждение только после того, как деньги поступят вам. Поэтому заинтересованы в быстром и успешном результате.</p>
                <p>1. Претензионный порядок: 30–40 дней. Страховая компания или банк возвращает средства полностью (или за неиспользованный период) либо направляет мотивированный отказ.</p>
                <p>2. Досудебный порядок: до 6 месяцев. При отказе финансового уполномоченного дело переходит в суд.</p>
                <p>3. Судебный порядок: 1–1,5 года.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading6">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse6" aria-expanded="false" aria-controls="collapse6"><i class="fa fa-question" aria-hidden="true"></i>В какой момент после покупки лучше к вам обращаться?</a>
      </h4>
    </div>
    <div id="collapse6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading6">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>Шансы на досудебный возврат выше, если вы обратились к нам в течение 30 дней с момента оформления кредита.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading7">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse7" aria-expanded="false" aria-controls="collapse7"><i class="fa fa-question" aria-hidden="true"></i>Требуется ли моё участие в деле?</a>
      </h4>
    </div>
    <div id="collapse7" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading7">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
               <p>Нет. Мы работаем по нотариальной доверенности и ведём дело без вашего участия.</p> 
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading8">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse8" aria-expanded="false" aria-controls="collapse8"><i class="fa fa-question" aria-hidden="true"></i>Нужно ли мне собирать дополнительные документы?</a>
      </h4>
    </div>
    <div id="collapse8" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading8">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>Как правило, нет. В редких случаях может потребоваться предоставить документы по запросу суда или страховой компании.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading9">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse9" aria-expanded="false" aria-controls="collapse9"><i class="fa fa-question" aria-hidden="true"></i>Что делать, если я получил какие-то документы по делу?</a>
      </h4>
    </div>
    <div id="collapse9" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading9">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>Сфотографируйте документы и отправьте их вашему специалисту через мессенджер или на электронную почту компании.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading10">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse10" aria-expanded="false" aria-controls="collapse10"><i class="fa fa-question" aria-hidden="true"></i>Как я получу свои деньги?</a>
      </h4>
    </div>
    <div id="collapse10" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading10">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>Средства поступят на ваш счёт. Вам нужно будет сообщить нам о получении денег или их отсутствии в установленный срок.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading11">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse11" aria-expanded="false" aria-controls="collapse11"><i class="fa fa-question" aria-hidden="true"></i>Как часто можно узнавать о статусе дела?</a>
      </h4>
    </div>
    <div id="collapse11" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading11">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>При судебном порядке рекомендуем запрашивать информацию не чаще 1 раза в 2 месяца.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading12">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse12" aria-expanded="false" aria-controls="collapse12"><i class="fa fa-question" aria-hidden="true"></i>Гарантируете ли вы возврат средств?</a>
      </h4>
    </div>
    <div id="collapse12" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading12">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>Мы не можем дать 100% гарантию — это противоречит юридической этике. Однако мы опираемся на положительную судебную практику и опыт нашей команды, и показываем хорошие результаты.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading13">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse13" aria-expanded="false" aria-controls="collapse13"><i class="fa fa-question" aria-hidden="true"></i>Что будет, если дело проиграем?</a>
      </h4>
    </div>
    <div id="collapse13" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading13">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>В этом случае вы ничего не оплачиваете и освобождаетесь от всех обязательств по договору.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading14">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse14" aria-expanded="true" aria-controls="collapse14"><i class="fa fa-question" aria-hidden="true"></i>Влияет ли возврат страховки на кредитную историю?</a>
      </h4>
    </div>
    <div id="collapse14" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading14">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                  <p>Нет. Возврат страховки и дополнительных услуг никак не влияет на кредитную историю.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading15">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse15" aria-expanded="false" aria-controls="collapse15"><i class="fa fa-question" aria-hidden="true"></i>Повысят ли процентную ставку после возврата денег?</a>
      </h4>
    </div>
    <div id="collapse15" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading15">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                 <p>В большинстве случаев ставка остаётся прежней. Точный ответ можно дать после анализа ваших кредитных документов.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading16">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse16" aria-expanded="false" aria-controls="collapse16"><i class="fa fa-question" aria-hidden="true"></i>Придётся ли возвращать скидку на автомобиль?</a>
      </h4>
    </div>
    <div id="collapse16" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading16">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                 <p>Нет. Мы защищаем интересы клиента и не допускаем изъятия скидки.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading17">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse17" aria-expanded="false" aria-controls="collapse17"><i class="fa fa-question" aria-hidden="true"></i>Что делать, если компания, оказавшая дополнительную услугу, уже банкрот?</a>
      </h4>
    </div>
    <div id="collapse17" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading17">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>Не отчаивайтесь, выход есть. Отправляйте документы на бесплатный анализ. Мы возвращаем средства как с компаний-исполнителей, так и напрямую с банков.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->   
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading18">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse18" aria-expanded="false" aria-controls="collapse18"><i class="fa fa-question" aria-hidden="true"></i>В каких городах вы работаете?</a>
      </h4>
    </div>
    <div id="collapse18" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading18">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>Основной регион, в котором мы работаем — Татарстан. Однако мы работаем дистанционно по всей России и успешно выигрываем дела в других городах.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->


<!-- Вопрос -->  
<div class="panel panel-default faq-content">
    <div class="panel-heading history-panel-heading" role="tab" id="heading19">
      <h4 class="panel-title history-panel-title single-accordion-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse19" aria-expanded="false" aria-controls="collapse19"><i class="fa fa-question" aria-hidden="true"></i>На что обращать внимание при покупке авто в кредит?</a>
      </h4>
    </div>
    <div id="collapse19" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading19">
        <div class="panel-body history-panel-body faq-body">
            <div class="faq-body-text">
                <p>Внимательно читайте все документы перед подписанием. Если заметили подозрительные условия уже после оформления — сразу обратитесь к юристу.</p>
            </div>
        </div>
    </div>
</div>
<!-- Вопрос -->
                                            
                                            

                                        </div>                            
                                    </div>                           
                                </div>   
                            </div>                          
                        </div>
                    </div>
					
                </div> 
            </div> 
        </div>        
    </section>
<!-- ВОПРОСЫ И ОТВЕТЫ -->    

<?php get_template_part( 'template-parts/zahvat2' ); ?>

<?php get_footer();?> 