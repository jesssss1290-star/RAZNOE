<?php
/*
 * Template Name: Услуга со страховыми
 * Template Post Type: post
 */
?>
<?php get_header();?>
<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
    <section class="feature-typo h-f-typo"> 
        <div class="container"> 
            <div class="row">                 
                <div class="col-md-12"> 
                    <div class="shop-single-review clearfix"> 
                        <div class="shop-review-content">  
                            <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                            <?php the_content(); ?>
                            <?php endwhile; ?><?php endif; ?>
                        </div>  
                    </div> 
                </div> 
            </div> 
        </div>                       
    </section> 
                    
		<section class="practice-area home-2-practice-area type-1-bg"> 
        <div class="container">
            <div class="row">
                <div class="h-2-practice-content clearfix">
                  	<?php get_template_part( 'template-parts/vozvrat' ); ?>
                    <div class="col-sm-12 col-md-6">
                        <!--<div class="accordion-single-page">
                            <div class="clearfix">
                                <div class="single-accordion-content">
                                    <div class="faq-accordion">
                                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                            <div class="panel panel-default faq-content">
                                                <div class="panel-heading history-panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title history-panel-title single-accordion-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"><i class="fa fa-gavel"></i>Правовая база 1</a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                                                    <div class="panel-body history-panel-body faq-body">
                                                        <div class="faq-body-text">
                                                              <p><?php the_field('baza1'); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default faq-content">
                                                <div class="panel-heading history-panel-heading" role="tab" id="headingTwo">
                                                  <h4 class="panel-title history-panel-title single-accordion-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"><i class="fa fa-gavel"> </i>Правовая база 2</a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                    <div class="panel-body history-panel-body faq-body">
                                                        <div class="faq-body-text">
                                                             <p><?php the_field('baza2'); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
											<div class="panel panel-default faq-content">
                                                <div class="panel-heading history-panel-heading" role="tab" id="headingThree">
                                                  <h4 class="panel-title history-panel-title single-accordion-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseTwo"><i class="fa fa-gavel"> </i>Правовая база 3</a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                    <div class="panel-body history-panel-body faq-body">
                                                        <div class="faq-body-text">
                                                             <p><?php the_field('baza3'); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>                            
                                    </div>                           
                                </div>   
                            </div>                          
                        </div>-->
                    </div>
					
					<div class="col-sm-12 col-md-6">
                        <!--<div class="accordion-single-page">
                            <div class="clearfix">
                                <div class="single-accordion-content">
                                    <div class="faq-accordion">
                                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                            <div class="panel panel-default faq-content">
                                                <div class="panel-heading history-panel-heading" role="tab" id="heading3">
                                                  <h4 class="panel-title history-panel-title single-accordion-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse3" aria-expanded="false" aria-controls="collapse3"><i class="fa fa-comment"> </i>Правовой комментарий 1</a>
                                                  </h4>
                                                </div>
                                                <div id="collapse3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3">
                                                    <div class="panel-body history-panel-body faq-body">
                                                        <div class="faq-body-text">
                                                             <p><?php the_field('comment1'); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default faq-content">
                                                <div class="panel-heading history-panel-heading" role="tab" id="heading4">
                                                  <h4 class="panel-title history-panel-title single-accordion-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse4" aria-expanded="false" aria-controls="collapse4"><i class="fa fa-comment"> </i>Правовой комментарий 2</a>
                                                  </h4>
                                                </div>
                                                <div id="collapse4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading4">
                                                    <div class="panel-body history-panel-body faq-body">
                                                        <div class="faq-body-text">
                                                            <p><?php the_field('comment2'); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
											<div class="panel panel-default faq-content">
                                                <div class="panel-heading history-panel-heading" role="tab" id="heading5">
                                                  <h4 class="panel-title history-panel-title single-accordion-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse5" aria-expanded="false" aria-controls="collapse4"><i class="fa fa-comment"> </i>Правовой комментарий 3</a>
                                                  </h4>
                                                </div>
                                                <div id="collapse5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading5">
                                                    <div class="panel-body history-panel-body faq-body">
                                                        <div class="faq-body-text">
                                                            <p><?php the_field('comment3'); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>                            
                                    </div>                           
                                </div>   
                            </div>                          
                        </div>-->
                    </div>
					
					
                </div> 
            </div> 
        </div>        
    </section>
<?php get_template_part( 'template-parts/strahi' ); ?>
<?php get_template_part( 'template-parts/zahvat2' ); ?>
<?php get_template_part( 'template-parts/team' ); ?>
<?php get_template_part( 'template-parts/other' ); ?>
    <section> 
    <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3Ad9004db1ea72bb39cd9827d39631046edb8d308c1bcd0377447fad51358f37bd&amp;width=100%25&amp;height=400&amp;lang=ru_RU&amp;scroll=true"></script> 
    </section> 

<?php get_footer();?> 