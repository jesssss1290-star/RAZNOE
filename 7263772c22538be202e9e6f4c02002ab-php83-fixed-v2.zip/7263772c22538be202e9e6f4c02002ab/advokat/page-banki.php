<?php get_header();?>
<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
<?php get_template_part( 'template-parts/banki' ); ?>
    <section class="feature-typo h-f-typo"> 
        <div class="container"> 
            <div class="row">                 
                <div class="col-md-12"> 
                    <div class="shop-single-review clearfix"> 
                        <div class="shop-review-content">  
                            <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                            <?php the_content(); ?>
                            <?php endwhile; ?><?php endif; ?>
                        </div>  
                    </div> 
										 
                </div> 
            </div> 
        </div>                       
    </section> 
<?php get_template_part( 'template-parts/zahvat2' ); ?>
<?php get_footer();?> 