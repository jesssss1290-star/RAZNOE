<?php
/*
 * Template Name: Услуга НОВАЯ
 * Template Post Type: post
 */
?>

<?php get_header();?>

<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
   
   <!-- КОНТЕНТ -->
    <section class="feature-typo h-f-typo"> 
        <div class="container">
            <div class="row">                 
                <div class="col-md-8"> 
                        <div class="shop-review-content">  
                            <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                            <?php the_content(); ?>
                            <?php endwhile; ?><?php endif; ?>
                        </div>  
                </div> 
				 <div class="col-md-4"> 
					<img src="<?php if ( has_post_thumbnail()) { $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full'); echo $large_image_url[0]; } ?>"  alt="<?php the_title(); ?>" class="img-fluid img-responsive">
                    <?php the_field('baza'); ?>
                </div> 
            </div> 
        </div>                       
    </section>
    
    <!-- КОНТЕНТ -->
    
    <?php get_template_part( 'template-parts/zahvat2' ); ?>
    <?php get_template_part( 'template-parts/strahi' ); ?>
    <?php get_template_part( 'template-parts/other' ); ?>
    
    <?php get_footer();?> 