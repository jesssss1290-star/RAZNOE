    <?php get_header();?>
    <?php get_template_part( 'template-parts/breadcrumbs' ); ?>
    <section class="contact-us-1">
        <div class="contact-us-1-area">
            <div class="container">
                <div class="row">
                    
                    <!-- КОНТАКТЫ -->
                    <div class="col-sm-6 col-md-6 no-padding-right">
                        <div class="col-md-12">
                            <div class="address-details">
                                <span>Телефон:</span>
                                <span><i class="fa fa-phone"></i><a href="tel:+79930901634">+7 (993) 090-16-34</a></span>   
								<span style="margin-left:46px;"><a href="tel:+78432032083">+7 (843) 203-20-83</a></span>
								<span style="margin-left:46px;"><a href="tel:+79376252083">+7 (937) 625-20-83</a></span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="address-details">
                                <span>E-mail:</span>
                                <span><i class="fa fa-envelope"></i><a href="mailto:advokatkzn.com@gmail.com">advokatkzn.com@gmail.com</a></span>
                            </div>
                       
                        <div class="address-details">
                            <span>Адрес:</span>
                            <span><i class="fa fa-map-marker"></i><a>г. Казань, ул. Петербургская, д.74</a></span>
                        </div>

						</div>	  
                    </div>
                    <!-- КОНТАКТЫ -->
                    
                    <!-- КАРТА -->
                    <div class="col-sm-6 col-md-6 no-padding ya-map">
                          <iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3Ad9004db1ea72bb39cd9827d39631046edb8d308c1bcd0377447fad51358f37bd&amp;source=constructor" width="100%" height="450" frameborder="0"></iframe>
                    </div>
                    <!-- КАРТА -->
                    
                </div>                
            </div>
        </div>
    </section>  
    
    
    
    <?php get_footer();?>