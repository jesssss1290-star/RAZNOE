
<!-- СТРАХОВЫЕ КОМПАНИИ -->
    <section style="padding-top: 50px;" class="testimonial-area home-5-testimonial-area type-1-bg">
        <div class="testimonial-content-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="owl-testimonial-content h-5-owl-testimonial-content">
                            <div class="Title-area">
                                <h2>Страховые и ассист компании</h2>
                            </div>
							<p>Есть немало компаний, которые навязывают людям лишние услуги и ненужные страховки. Форма может быть разной: услуги автосалона, независимая или дополнительная гарантия, карты помощи на дороге, страховка жизни и имущества и т. п. Мы работаем со всеми случаями и любыми компаниями в Российской Федерации.</p> 
							 <div class="asset-button btn-text-left text-left ">
                            <button type="button" class="btn btn-default"><a href="/svyazki-bankov/">Все компании >></a></button>
                        </div>
                        </div>
                    </div>
                    <div class="col-md-6 no-padding-left">
                        <div id="home-5-testimonial-demo" class="owl-carousel owl-theme">
                            
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                       <a href="/tag/d-s-avto/"><img src="<?php echo get_template_directory_uri();?>/images/assist/dsavto.jpg" alt="дсавто возврат независимой гарантии"></a>
                                    </div>
                                    <div class="home-5-t-s-img">
										<a href="/tag/avtomobilnyj-spasatel/"><img src="<?php echo get_template_directory_uri();?>/images/assist/avtospas.jpg" alt="автомобильный спасатель возврат карты техпомощи на дорогах"></a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                        <a href="/tag/avto-kvartal/"><img src="<?php echo get_template_directory_uri();?>/images/assist/ars.jpg" alt="возврат денег за карту помощи ARS"></a>
                                    </div>
                                    <div class="home-5-t-s-img">
                                    	 <a href="/tag/aura-avto/"><img src="<?php echo get_template_directory_uri();?>/images/assist/aura.jpg" alt="возврат денег за опционный договор"></a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                       <a href="/tag/asp/"><img src="<?php echo get_template_directory_uri();?>/images/strah/asp.jpg" alt="возврат денежных средств за опционный договор от ООО АСП"></a>
                                    </div>
                                    <div class="home-5-t-s-img">
										<a href="/tag/prioritet/"><img src="<?php echo get_template_directory_uri();?>/images/strah/prioritet.jpg" alt="как быстро вернуть деньги за опционный договор с ООО Приоритет-Авто"></a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                        <a href="/tag/garant/"><img src="<?php echo get_template_directory_uri();?>/images/assist/garant.jpg" alt="возврат за карту техпомощи Гарант"></a>
                                    </div>
                                    <div class="home-5-t-s-img">
                                    	<a href="/tag/avtopomosh/"><img src="<?php echo get_template_directory_uri();?>/images/assist/avtopamosh.jpg" alt="возврат денег от автопомощь"></a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                   		<a href="/tag/ankor/"><img src="<?php echo get_template_directory_uri();?>/images/assist/ankor.jpg" alt="возврат независимой гарантии от Анкор"></a>
                                    </div>
                                    <div class="home-5-t-s-img">
                                    	<a href="/tag/avto-zashhita/"><img src="<?php echo get_template_directory_uri();?>/images/assist/avtozashita.jpg" alt="возврат независимой гарантии от Авто-защита"></a>
                                    </div>
                                </div>
                            </div>
							
							<div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                       <a href="/tag/broker/"></a><img src="<?php echo get_template_directory_uri();?>/images/assist/broker.jpg" alt="возврат денег за сертификат о выдаче независимой гарантии с ООО Брокер">
                                    </div>
                                    <div class="home-5-t-s-img">
                                      <a href="/tag/eus/"> <img src="<?php echo get_template_directory_uri();?>/images/assist/eus.jpg" alt="ЕЮС возврат денег за сертификат юридической помощи"></a>
                                    </div>
                                </div>
                            </div>
							
							<div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                       <a href="/tag/direkta/"></a><img src="<?php echo get_template_directory_uri();?>/images/assist/direkta.jpg" alt="отказ от карты помощи ООО Директ А">
                                    </div>
                                    <div class="home-5-t-s-img">
                                      <a href="#"> <img src="<?php echo get_template_directory_uri();?>/images/assist/povoljie.jpg" alt="отказ от услуг Ассистанс Поволжье"></a>
                                    </div>
                                </div>
                            </div>
							
							<div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                       <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/assist/carcontinent.jpg" alt="возврат денег от Кар Корнтинент за услугу автодруг"></a>
                                    </div>
                                    <div class="home-5-t-s-img">
                                      <a href="/tag/kautella/"> <img src="<?php echo get_template_directory_uri();?>/images/assist/cautela.jpg" alt="каутелла возврат независимой гарантии"></a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                       <img src="<?php echo get_template_directory_uri();?>/images/assist/medoblako.jpg" alt="медоблако отказ от сертификата">
                                    </div>
                                    <div class="home-5-t-s-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/assist/garantavtocom.jpg" alt="гарантавтоком отказ от программы автоэксперт">
                                    </div>
                                </div>
                            </div>
							
							<div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                       <img src="<?php echo get_template_directory_uri();?>/images/assist/patrul.jpg" alt="как вернуть деньги за сертификат технической помощи от ООО Ассист Патруль">
                                    </div>
                                    <div class="home-5-t-s-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/assist/rat.jpg" alt="отказ от техпомощи на дороге">
                                    </div>
                                </div>
                            </div>

                        </div>
                        
                        <div class="testimonial-customNavigation home-5-customNavigation">
                          <div class="btn prev"><i class="fa fa-long-arrow-left"></i></div>
                          <div class="btn next"><i class="fa fa-long-arrow-right"></i></div>
                        </div>
                        
                    </div>                    
                </div>
            </div>
        </div>       
    </section>
<!-- СТРАХОВЫЕ КОМПАНИИ -->