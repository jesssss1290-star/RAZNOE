
<!-- КРОШКИ -->    
    <section class="page-title-area shop-title-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-title-padding">
                        <div class="page-title-content text-center">
                          <h1><?php single_cat_title(); ?></h1>
                        </div>
                        <div class="breadcrumbs text-center">
                          <?php
                               if ( function_exists('yoast_breadcrumb') ) {
                               yoast_breadcrumb('<span id="breadcrumbs">','</span>'); }?>                       
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!-- КРОШКИ -->  