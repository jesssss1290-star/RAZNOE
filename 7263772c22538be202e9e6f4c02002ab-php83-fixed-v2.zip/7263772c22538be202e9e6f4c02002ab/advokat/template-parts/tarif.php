
<!-- ТАРИФЫ -->
<section class="pricing-table">
        
        
        <div class="welcome-title-area">
            <div class="container">
                <div class="Title-area">
                     <span class="h3">Оплата услуг только после завершения дела и полной выплаты</span>
                     <h2>Стоимость услуг</h2>
                     <p>Более подробно все <b><a href="/czeny-i-sroki/">цены и сроки</a></b> - описаны на этой странице.</p>
                </div>
             </div>
        </div>
        
<!-- Карточки -->        
        <div class="container">
            <div class="row">
                
                <!-- карточка 1 -->
                <div class="col-md-4 col-sm-6">
                    <div class="single-pricing-table">
                        
                        <div class="pricing-table-header text-center">
                            <p class="text-center">Вариант 1<br>«Претензионный порядок»</p>
                        </div>
                        
                        <div class="pricing-table-content">
                            <p>Первичная консультация - 2000руб.</p>
                            <div class="pricing-table-content-list">
                                <ul>
                                    <li><i class="fa fa-long-arrow-right"></i>От 500 000р. < 10%</li>
                                    <li><i class="fa fa-long-arrow-right"></i>От 50 000р. до 500 000р. - 10%</li>
                                    <li><i class="fa fa-long-arrow-right"></i>До 50 000р. - 30%</li>
                                </ul>
                            </div>
                            <div class="pricing-btn">
                                <a href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" >Консультация</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- карточка 1 -->
                
                <!-- карточка 2 -->
                <div class="col-md-4 col-sm-6">
                    <div class="single-pricing-table">
                        
                        <div class="pricing-table-header text-center">
                            <p class="text-center">Вариант 2<br>«Досудебный порядок»</p>
                        </div>
                        
                        <div class="pricing-table-content">
                            <p>Первичная консультация - 3000руб.</p>
                            <div class="pricing-table-content-list">
                                <ul>
                                     <li><i class="fa fa-long-arrow-right"></i>Комиссия от возвращённой клиенту суммы - 30%</li>
                                </ul>
                                <br>
                            </div>
                            <div class="pricing-btn">
                                <a href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" >Консультация</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- карточка 2 -->
                
                <!-- карточка 3 -->
                <div class="col-md-4 col-sm-6">
                    <div class="single-pricing-table">
                        
                        <div class="pricing-table-header text-center">
                            <p class="text-center">Вариант 3<br>«Судебный порядок»</p>
                        </div>
                        
                        <div class="pricing-table-content">
                            <p>Первичная консультация - 5000руб.</p>
                            <div class="pricing-table-content-list">
                                <ul>
                                    <li><i class="fa fa-long-arrow-right"></i>Своё вознаграждение мы взыскиваем с ответчика, но не менее платы, которая могла бы быть получена в досудебном порядке.</li>
                                </ul>
                            </div>
                            <div class="pricing-btn">
                                <a href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" >Консультация</a>
                            </div>
                        </div>
                        
                        
                    </div>
                </div>
                <!-- карточка 3 -->
                
            </div>
        </div>
<!-- Карточки --> 

</section>
<!-- ТАРИФЫ -->