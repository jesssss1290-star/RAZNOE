<!-- БЛОК ВЫИГРАННЫХ ДЕЛ -->
<section class="home-6-help-area type-1-bg delav">
  <div class="container">
    <div class="row">

      <div class="col-md-7 dela-col">
        <div class="Title-area">
         <h2>Выигранные дела</h2>
       </div>
       <div class="prokrutka">
       <table class="table">
        <tbody>
          <?php $my_posts = get_posts('numberposts=15&category=38&orderby=date'); foreach ($my_posts as $post) :setup_postdata($post); ?>
          <tr>
            <th scope="row"><?php $data = get_field(data); ?><?php if($data!="") { echo $data; } ?></th>
            <td><?php $nazvanie = get_field(nazvanie); ?><?php if($nazvanie!="") { echo $nazvanie; } ?></td>
            <td><?php $summa = get_field(summa); ?><?php if($summa!="") { echo $summa; } ?>₽</td>
            <td><a href="<?php the_permalink();?>">Подробнее</a></td>
          </tr>
          <?php wp_reset_postdata();?>
          <?php endforeach; ?>
        </tbody>
      </table>
      </div>
      
    <div class="statusd asset-butt on">
        <button type="button" class="btn btn-default"><a href="/proverit-status-dela/">Проверить статус дела</a></button>
    </div>
      
    </div>

  <div class="col-md-5">
   <img src="/wp-content/themes/advokat/images/2fon.jpg" alt="возврат страховки по кредиту">
 </div>
</div>
</div>
</section>
<!-- БЛОК ВЫИГРАННЫХ ДЕЛ -->