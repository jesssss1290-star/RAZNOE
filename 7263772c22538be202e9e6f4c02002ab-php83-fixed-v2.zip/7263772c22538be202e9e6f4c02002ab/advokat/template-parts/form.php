<!-- СПИСОК БАНКОВ -->
  <div class="sidebar-inner">
     <h2>Компании</h2>
     <div class="tag-cloud">
        <a href="/tag/alfabank/">АльфаБанк</a>
        <a href="/tag/vtb/">ВТБ</a>
        <a href="/tag/avto-kvartal/">Авто Квартал</a>
        <a href="/tag/avto-zashhita/">Авто-Защита</a>
        <a href="/tag/avtomobilnyj-spasatel/">Автомобильный спасатель</a>
        <a href="/tag/avtopomosh/">Автопомощь</a>
        <a href="/tag/ankor/">Анкор</a>
        <a href="/tag/asp/">АСП</a>
        <a href="/tag/aura-avto/">Аура-Авто</a>
 		<a href="/tag/broker/">Брокер</a>
 		<a href="/tag/garant/">Гарант</a>
 		<a href="/tag/d-s-avto/">Д.С.Авто</a>
 		<a href="/tag/direkta/">Директ А</a>
 		<a href="/tag/eus/">ЕЮС</a>
 		<a href="/tag/kautella/">Каутелла</a>
 		<a href="/tag/prioritet/">Приоритет-Авто</a>
 		<a href="/tag/psb/">ПСБ</a>
 		<a href="/tag/rolf/">Рольф</a>
 		<a href="/tag/sber/">СБЕР</a>
 		<a href="/tag/sovkombank/">СовКомБанк</a>					
     </div>
 </div>
<!-- СПИСОК БАНКОВ -->