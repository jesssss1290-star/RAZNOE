
<!-- АССИСТ КОМПАНИИ -->
    <section style="padding-top: 50px;" class="testimonial-area home-5-testimonial-area type-1-bg">
        <div class="testimonial-content-area">
            <div class="container">
                <div class="row">

                    <div class="col-md-6">
                        <div class="owl-testimonial-content h-5-owl-testimonial-content">
                            <i class="fa fa-star"></i>
                            <div class="Title-area">
                                <span class="h3"></span>
                                <h2>Ассист компании</h2>
                            </div>
                            <p>Навязанные услуги автосалонов, независимые гарантии, карты помощи на дороге</p> 
							 <div class="asset-button btn-text-left text-left ">
                            <button type="button" class="btn btn-default"><a href="/strahovye/">Все ассист компании >></a></button>
                        </div>
                        </div>
                    </div>
                    
					<div class="col-md-6 no-padding-left">
                        <div id="home-5-testimonial-demo" class="owl-carousel owl-theme">
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                       <img src="<?php echo get_template_directory_uri();?>/images/assist/povoljie.jpg" alt="отказ от услуг Ассистанс Поволжье">
                                    </div>
                                    <div class="home-5-t-s-img">
                                       <img src="<?php echo get_template_directory_uri();?>/images/assist/cautela.jpg" alt="каутелла возврат независимой гарантии">
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                       <img src="<?php echo get_template_directory_uri();?>/images/assist/carcontinent.jpg" alt="возврат денег от Кар Корнтинент за услугу автодруг">
                                    </div>
                                    <div class="home-5-t-s-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/assist/crossassist.jpg" alt="возврат денег от Кросс Ассист за услугу автодруг">
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                       <img src="<?php echo get_template_directory_uri();?>/images/assist/medoblako.jpg" alt="медоблако отказ от сертификата">
                                    </div>
                                    <div class="home-5-t-s-img">
                                        <img src="<?php echo get_template_directory_uri();?>/images/assist/garantavtocom.jpg" alt="гарантавтоком отказ от программы автоэксперт">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="testimonial-customNavigation home-5-customNavigation">
                          <div class="btn prev"><i class="fa fa-long-arrow-left"></i></div>
                          <div class="btn next"><i class="fa fa-long-arrow-right"></i></div>
                        </div>
                    </div> 
                                      
                </div>
            </div>
        </div>       
    </section>
<!-- АССИСТ КОМПАНИИ -->