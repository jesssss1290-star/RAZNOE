<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Ysabeau+Infant:wght@700&display=swap" rel="stylesheet">

<!-- НОВЫЙ СЛАЙДЕР -->
    <div class="rev_slider_wrapper rev_slider_wrapper-no-margin">
        <div id="slider1" class="rev_slider"  data-version="5.0">
            <ul> 
                     
                     <!-- СЛАЙД1 -->
                     <li data-index="rs-14" data-transition="parallaxtoright" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-delay="7000" data-rotate="0" data-saveperformance="off" data-title="Slider3-Layer1" data-description="">
                        <!-- Изображение -->
                        <img src="/wp-content/uploads/2025/01/bg-slider8.jpg" class="no-lazyload" alt="" width="2000" height="600" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>
                        <!-- Изображение -->

                        <!-- Логотип -->
                        <div class="tp-caption tp-resizeme rs-parallaxlevel-0" 
                            id="slide-14-layer-13" 
                            data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                            data-y="['top','top','top','top']" data-voffset="['140','140','140','100']" 
                            data-width="none"
                            data-height="none"
                            data-whitespace="nowrap"
                            data-transform_idle="o:1;"
                            data-transform_in="y:-50px;opacity:0;s:500;e:Power2.easeInOut;" 
                            data-transform_out="y:-50px;opacity:0;s:500;s:500;" 
                            data-start="700" 
                            data-responsive_offset="on"
                            style="z-index: 5; filter: drop-shadow(0 0 8px #000);"><img src="/wp-content/themes/advokat/images/logo-minn.png" class="no-lazyload" alt="" width="55" height="69" data-ww="['55px','55px','55px','55px']" data-hh="['69px','69px','69px','69px']" data-no-retina> 
                        </div>
                        <!-- Логотип -->

                        <!-- Боковинка левая -->
                        <div class="tp-caption tp-resizeme rs-parallaxlevel-0" 
                            id="slide-14-layer-12" 
                            data-x="['center','center','center','center']" data-hoffset="['-75','-75','-75','-75']" 
                            data-y="['top','top','top','top']" data-voffset="['158','158','158','118']" 
                            data-width="none"
                            data-height="none"
                            data-whitespace="nowrap"
                            data-transform_idle="o:1;"
                            data-transform_in="x:-50px;opacity:0;s:500;e:Power2.easeInOut;" 
                            data-transform_out="x:-50px;opacity:0;s:500;s:500;" 
                            data-start="900" 
                            data-responsive_offset="on" 
                            style="z-index: 6;"><img src="/wp-content/uploads/2025/01/est2.jpg" class="no-lazyload" alt="" width="32" height="18" data-ww="['32px','32px','32px','32px']" data-hh="['18px','18px','18px','18px']" data-no-retina> 
                        </div>
                        <!-- Боковинка левая -->

                        <!-- Боковинка правая -->
                        <div class="tp-caption tp-resizeme rs-parallaxlevel-0" 
                            id="slide-14-layer-14" 
                            data-x="['center','center','center','center']" data-hoffset="['75','75','75','75']" 
                            data-y="['top','top','top','top']" data-voffset="['158','158','158','118']" 
                            data-width="none"
                            data-height="none"
                            data-whitespace="nowrap"
                            data-transform_idle="o:1;"
                            data-transform_in="x:50px;opacity:0;s:500;e:Power2.easeInOut;" 
                            data-transform_out="x:50px;opacity:0;s:500;s:500;" 
                            data-start="900" 
                            data-responsive_offset="on" 
                            style="z-index: 7;"><img src="/wp-content/uploads/2025/01/20142.jpg" class="no-lazyload" alt="" width="32" height="18" data-ww="['32px','32px','32px','32px']" data-hh="['18px','18px','18px','18px']" data-no-retina> 
                        </div>
                        <!-- Боковинка правая -->
                        
                        <!-- Заголовок -->
                        <div class="tp-caption" 
                            id="slide-14-layer-2" 
                            data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                            data-y="['top','top','top','top']" data-voffset="['235','235','235','210']" 
                            data-width="none"
                            data-height="none"
                            data-fontsize="['90','80','75','72']"
                            data-lineheight="['90','80','75','72']"
                            data-whitespace="nowrap"
                            data-transform_idle="o:1;"
                            data-transform_in="y:50px;opacity:0;s:500;e:Power2.easeInOut;" 
                            data-transform_out="y:50px;opacity:0;s:500;s:500;" 
                            data-start="1500" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on" 
                            style="z-index: 9; white-space: nowrap; font-size: 100px; line-height: 90px; color: rgba(255, 255, 255, 1.00); font-weight: 700; font-family: Ysabeau Infant;">PRO.VOZVRAT 
                        </div>
                        <!-- Заголовок -->

                        <!-- Подпись -->
                        <div class="tp-caption tp-resizeme rs-parallaxlevel-0" 
                            id="slide-14-layer-16" 
                            data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                            data-y="['top','top','top','top']" data-voffset="['338','338','338','338']" 
                            data-width="none"
                            data-height="none"
                            data-whitespace="nowrap"
                            data-transform_idle="o:1;"
                            data-transform_in="y:50px;opacity:0;s:500;e:Power2.easeInOut;" 
                            data-transform_out="y:50px;opacity:0;s:500;s:500;" 
                            data-start="1800" 
                            data-responsive_offset="on" 
                            style="z-index: 10;"><img class="no-lazyload" src="/wp-content/uploads/2025/01/podpis.png" alt="" width="384" height="20" data-ww="['384px','384px','384px','384px']" data-hh="['20px','20px','20px','20px']" data-no-retina> 
                        </div>
                        <!-- Подпись -->
                        
                        
                        <!-- Белая линия -->
                        <div class="tp-caption rs-parallaxlevel-0" 
                            id="slide-14-layer-15" 
                            data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                            data-y="['top','top','top','top']" data-voffset="['354','354','354','354']" 
                            data-width="none"
                            data-height="none"
                            data-whitespace="nowrap"
                            data-transform_idle="o:1;"
                            data-transform_in="y:50px;opacity:0;s:500;e:Power2.easeInOut;" 
                            data-transform_out="y:50px;opacity:0;s:500;s:500;" 
                            data-start="2000" 
                            data-responsive_offset="on" 
                            style="z-index: 8;"><img class="no-lazyload" src="/wp-content/uploads/2025/01/line-white.jpg" alt="" width="384" height="2" data-ww="['384px','384px','384px','384px']" data-hh="['2px','2px','2px','2px']" data-no-retina> 
                        </div>
                        <!-- Белая линия -->

                        <!-- Надпись -->
                        <div class="tp-caption Fashion-BigDisplay rs-parallaxlevel-0" 
                            id="slide-14-layer-18" 
                            data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                            data-y="['top','top','top','top']" data-voffset="['404','404','404','404']" 
                            data-width="none"
                            data-height="none"
                            data-whitespace="nowrap"
                            data-transform_idle="o:1;"
                            data-transform_in="x:-50px;opacity:0;s:500;e:Power2.easeInOut;" 
                            data-transform_out="x:50px;opacity:0;s:500;s:500;" 
                            data-start="2100" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on" 
                            style="z-index: 11; white-space: nowrap; font-size: 17px; line-height: 26px; font-weight: 400; color: rgba(229, 228, 228, 1.00);font-family:Open Sans;"><div class="text-center hidden-sm hidden-xs" style="font-style: italic; letter-spacing: normal;">
                            Оформили кредит в банке или автосалоне и вам навязали ненужную страховку или продали какие-то ненужные услуги?<br/>
                            Обращайтесь, и мы вернём <b>все ваши деньги</b> с гарантией!
                            
                            </div> 
                        </div>
                        <!-- Надпись -->

                        <!-- Кнопка -->
                        <div class="tp-caption small_thin_grey rs-parallaxlevel-0" 
                            
                            id="slide-14-layer-19" 
                            data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                            data-y="['top','top','top','top']" data-voffset="['483','483','420','400']" 
                            data-width="none"
                            data-height="none"
                            data-whitespace="nowrap"
                            data-transform_idle="o:1;"
                            data-transform_in="x:50px;opacity:0;s:500;e:Power2.easeInOut;" 
                            data-transform_out="x:-50px;opacity:0;s:500;s:500;" 
                            data-start="2300" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on" 
                            style="z-index: 12; white-space: nowrap; color: rgba(117, 117, 117, 1.00);padding:1px 4px 1px 4px;border-color:rgba(255, 214, 88, 1.00);"
                        >
                            
                        <a href="" class="btn btn-primary rev-slider-btn-1 rev-slider-btn-2" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" >Заявка на консультацию</a> 
                        </div>
                        <!-- Кнопка -->
                    </li>
                    <!-- СЛАЙД1 -->
                    
                    
                    
                    
                    <!-- СЛАЙД2 -->
                    <li data-index="rs-6" data-transition="parallaxtoright" data-slotamount="default"  data-easein="default" data-easeout="default" data-masterspeed="default" data-delay="6510"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-description="">
                        
                        <!-- Изображение -->
                        <img src="/wp-content/uploads/2025/01/bg-slider8-3.jpg"  alt=""  width="1920" height="1280" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>
                        <!-- Изображение -->

                        <!-- Верхняя подпись -->
                        <div class="tp-caption tp-resizeme rs-parallaxlevel-0" 
                            id="slide-6-layer-1" 
                            data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                            data-y="['top','top','top','top']" data-voffset="['180','180','180','180']" 
                            data-width="none"
                            data-height="none"
                            data-whitespace="nowrap"
                            data-transform_idle="o:1;"
                            data-transform_in="x:-50px;opacity:0;s:500;e:Power2.easeInOut;" 
                            data-transform_out="x:50px;opacity:0;s:500;s:500;" 
                            data-start="700" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on" 
                            style="z-index: 5; white-space: nowrap; font-size: 17px; line-height: 28px; font-weight: 400; color: rgba(241, 241, 241, 1.00);font-family:Open Sans;"
                        > 
                            <span class="sl-italic">Совсем нет времени на визиты в суд?</span> 
                        </div>
                        <!-- Верхняя подпись -->

                        <!-- Крупная надпись -->
                        <div class="tp-caption tp-resizeme rs-parallaxlevel-0 text-center" 
                            id="slide-6-layer-2" 
                            data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                            data-y="['top','top','top','top']" data-voffset="['225','225','225','225']" 
                            data-width="none"
                            data-height="none"
                            data-fontsize="['40','30','28','25']"
                            data-lineheight="['40','40','35','30']"
                            data-whitespace="nowrap"
                            data-transform_idle="o:1;"
                            data-transform_in="x:50px;opacity:0;s:500;e:Power2.easeInOut;" 
                            data-transform_out="x:-50px;opacity:0;s:500;s:500;" 
                            data-start="1200" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on" 
                            style="z-index: 6; white-space: nowrap; color: rgba(255, 255, 255, 1.00); font-weight: 700; font-family: Ysabeau Infant;">
                            <span class="text-center" style="text-transform: uppercase;">
                                Ведём все дела без вашего участия<br/>
                                нужен всего один визит в наш офис
                            </span> 
                        </div>
                        <!-- Крупная надпись -->

                        <!-- Вертикальная линия -->
                        <div class="tp-caption tp-resizeme rs-parallaxlevel-0" 
                            id="slide-6-layer-3" 
                            data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                            data-y="['top','top','top','top']" data-voffset="['364','364','364','364']" 
                            data-width="none"
                            data-height="none"
                            data-whitespace="nowrap"
                            data-transform_idle="o:1;"
                            data-transform_in="y:50px;opacity:0;s:500;e:Power2.easeInOut;" 
                            data-transform_out="y:50px;opacity:0;s:500;s:500;" 
                            data-start="1700" 
                            data-responsive_offset="on" 
                            style="z-index: 7;"><img src="/wp-content/uploads/2025/01/line-slider.jpg" alt="" width="2" height="34" data-ww="['2px','2px','2px','2px']" data-hh="['34px','34px','34px','34px']" data-no-retina> 
                        </div>
                        <!-- Вертикальная линия -->

                        <!-- Кнопка -->
                        <div class="tp-caption small_text tp-resizeme rs-parallaxlevel-0" 
                            id="slide-6-layer-4" 
                            data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                            data-y="['top','top','top','top']" data-voffset="['428','428','428','428']" 
                            data-width="none"
                            data-height="none"
                            data-whitespace="nowrap"
                            data-transform_idle="o:1;"
                            data-transform_in="y:50px;opacity:0;s:500;e:Power2.easeInOut;" 
                            data-transform_out="y:50px;opacity:0;s:500;s:500;" 
                            data-start="2200" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on" 
                            style="z-index: 8; white-space: nowrap;"><a class="btn btn-default-alt rev-slider-btn-1" href=" " data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow">Бесплатная консультация</a> 
                        </div>
                        <!-- Кнопка -->
                    </li>
                    <!-- СЛАЙД2 -->
                   
                   <style> 
                   .bullet{top: 104% !important; left: 48.5% !important} 
                   
                   @media only screen and (max-width : 800px) {
                      .tp-leftarrow, .tp-rightarrow, .tp-bullets {display: none !important;}
                      .rev-slider-btn-1:focus, .rev-slider-btn-1:visited, .rev-slider-btn-1:active {text-transform: uppercase;}
                       
                   }
                   
                  @media only screen and (max-width : 380px) {
                      .tp-leftarrow, .tp-rightarrow, .tp-bullets {display: none !important;}
                       
                   } 
                  
                   
                  @media only screen and (max-width : 370px) {
                      .tp-leftarrow, .tp-rightarrow, .tp-bullets {display: none !important;}
                       
                   }
                   
                   
                   
                   </style>
                   
            </ul>             
        </div>
    </div>

<!-- НОВЫЙ СЛАЙДЕР -->