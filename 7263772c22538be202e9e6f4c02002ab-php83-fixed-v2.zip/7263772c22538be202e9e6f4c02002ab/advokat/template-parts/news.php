
<!-- НОВОСТИ -->
    <section class="testimonial-area home-2-testimonial-area otzivs">
        
        <div class="welcome-title-area">
            <div class="container">
                <div class="row">
                    <div class="col-xs-8 col-sm-6">
                        <div class="Title-area">
                            <span class="h3">Интересная информация</span>
                            <h2>Новости и статьи</h2>
                        </div>
                    </div>
                    <div class="col-xs-4 col-sm-6">
                        <div class="asset-button btn-text-left text-right top-margin">
                            <button type="button" class="btn btn-default"><a href="/news/">Все новости</a></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="testimonial-content-area news-main">
            <div class="container">
                <div class="row">
                    <div class="t-b-content-area">
                        <?php $my_posts = get_posts('numberposts=4&category=12&orderby=date'); foreach ($my_posts as $post) :setup_postdata($post); ?>
                        
                        <!-- новость -->
                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <div class="row t-b-details">
                                <div class="t-b-img col-sm-12 col-xs-4">
                                    <a href="<?php the_permalink();?>"><img src="<?php if ( has_post_thumbnail()) { $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'medium'); echo $large_image_url[0]; } ?>"  alt="<?php the_title(); ?>"></a>
                                </div>
                                    <div class="opis col-sm-12 col-xs-8">
                                    <h4><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h4>
								    <div class="t-b-comment"><p><i class="fa fa-pencil-square" aria-hidden="true"></i> Опубликовано: <span><?php the_date();?></span></p></div>
                                </div>
                            </div>
                        </div>
                        <!-- новость -->
                        
                        <?php wp_reset_postdata();?>
                        <?php endforeach; ?>           
                    </div>    
                </div>
            </div>
        </div>
        
    </section>
<!-- НОВОСТИ -->
