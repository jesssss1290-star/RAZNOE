
<!-- ДРУГИЕ -->
<section>    
	 <div class="container">
                <div class="other">
                   <div class="col-xs-12 col-sm-10">
                        <div class="Title-area">
                           <h2>Другие навязанные услуги</h2> 
                        </div>
                    </div>
                    <?php $my_posts = get_posts('numberposts=3&category=1&orderby=rand'); foreach ($my_posts as $post) :setup_postdata($post); ?>
                    <div class="col-xs-12 col-sm-6 col-md-4">
                        <div class="shop-content-inner">
                            <div class="shop-content-img">
                                <a href="<?php the_permalink();?>"><img src="<?php if ( has_post_thumbnail()) { $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full'); echo $large_image_url[0]; } ?>"  alt="<?php the_title(); ?>"></a>
                                <div class="shop-content-img-hover">
                                    <div class="shop-content-img-hover-text">
                                        <a href="<?php the_permalink();?>">Подробнее</a>
                                        <a href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Консультация</a>
                                    </div> 
                                </div> 
                            </div>
                            <div class="shop-content-text">
                                <h2><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h2>
                            </div>
                        </div>
                    </div>
                    <?php wp_reset_postdata();?>
                    <?php endforeach; ?>  
                </div>
	 </div>
</section>
<!-- ДРУГИЕ -->