
<!-- СЛАЙДЕР -->
<div style="background: #000;" class="mainsliderbootstrap">
    <div class="container">
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
               
            </ol>
            <div class="carousel-inner"> 
               <div class="item active">
                  <img src="/wp-content/themes/advokat/images/9024567.webp"  alt="Ваш Адвокат">
                    <div class="container">
                        <div class="carousel-caption">
                            <div class="upper-column info-box">
                                <div class="icon-box"></div>
                            </div>
                            
							 <div class="heading-rp-small">Вернем навязанные банком страховки<br> и дополнительные услуги</div>
                            <button class="btn button btn-default rev-slider-btn-1 rev-slider-btn-2" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Закажите бесплатную консультацию</button> 
                        </div>
                    </div>
                </div>   
				<div class="item">
					<img src="/wp-content/themes/advokat/images/page-title-v51.webp"  alt="возврат страховки по кредиту">
                    <div class="container">
                        <div class="carousel-caption">
                            <div class="upper-column info-box">
                                <div class="icon-box"></div>
                            </div>
                           <div class="heading-rp-small">Более 5000 оформленных возвратов,<br> 99% успешных сделок</div>
                           <button class="btn button btn-default rev-slider-btn-1 rev-slider-btn-2" href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class="theme-button">Закажите бесплатную консультацию</button> 
                        </div>
                    </div>
                </div>
				 <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                <i class="fa fa-angle-left" aria-hidden="true"></i>
                <span class="sr-only">Пред</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next">
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <span class="sr-only">След</span>
            </a>
            </div>
      </div>
   </div>
</div>
<!-- СЛАЙДЕР -->
