
<!-- БАНКИ -->
    <section class="our-client-area">
        <div class="client-slider">
            <div class="container">
                
                    <div class="client-content">
                        <div id="client-demo" class="owl-carousel owl-theme">
                            
                            <div class="item client-item">
                                <a href="/tag/alfabank/"><img src="<?php echo get_template_directory_uri();?>/images/bank/alf.jpg" alt="возврат страховки альфа банка"></a>
                            </div>
							
							<div class="item client-item">
                                <a href="/tag/psb/"><img src="<?php echo get_template_directory_uri();?>/images/bank/psb.jpg" alt="возврат страховки промсвязьбанка"></a>
                            </div>
                            
                            <div class="item client-item">
                               <img src="<?php echo get_template_directory_uri();?>/images/bank/pochta.jpg" alt="возврат страховки почта банка">
                            </div>
                            
                            <div class="item client-item">
								<a href="/tag/vtb/"><img src="<?php echo get_template_directory_uri();?>/images/bank/vtb.jpg" alt="возврат страховки втб"></a>
                            </div>
                            
                            <div class="item client-item">
                               <img src="<?php echo get_template_directory_uri();?>/images/bank/otk.jpg" alt="возврат страховки отк банка">
                            </div>
                            
                            <div class="item client-item">
                               <img src="<?php echo get_template_directory_uri();?>/images/bank/abb.jpg" alt="возврат страховки ак барс банка">
                            </div>
                            
                            <div class="item client-item">
								<a href="/tag/sber/"><img src="<?php echo get_template_directory_uri();?>/images/bank/sbr.jpg" alt="возврат страховки сбера"></a>
                            </div>
                            
                            <div class="item client-item">
                                <img src="<?php echo get_template_directory_uri();?>/images/bank/ren.jpg" alt="возврат страховки">
                            </div>
                            
                            <div class="item client-item">
                                <img src="<?php echo get_template_directory_uri();?>/images/bank/uralsib.jpg" alt="возврат страховки уралсиб">
                            </div>
                            
                            <div class="item client-item">
                                <img src="<?php echo get_template_directory_uri();?>/images/bank/mts.jpg" alt="возврат страховки мтс банка">
                            </div>
                            
                            <div class="item client-item">
                                <img src="<?php echo get_template_directory_uri();?>/images/bank/tin.jpg" alt="возврат страховки тинькоф банка">
                            </div>
                            
                            <div class="item client-item">
                                 <a href="/tag/sovkombank/"><img src="<?php echo get_template_directory_uri();?>/images/bank/skb.jpg" alt="возврат страховки совкомбанка"></a>
                            </div>
							
							<div class="item client-item">
								 <a href="/tag/alfabank/"><img src="<?php echo get_template_directory_uri();?>/images/bank/alf.jpg" alt="возврат страховки альфа банка"></a>
                            </div>
							
							<div class="item client-item">
                                <a href="/tag/psb/"><img src="<?php echo get_template_directory_uri();?>/images/bank/psb.jpg" alt="возврат страховки промсвязьбанка"></a>
                            </div>
                            
                            <div class="item client-item">
                               <img src="<?php echo get_template_directory_uri();?>/images/bank/pochta.jpg" alt="возврат страховки почта банка">
                            </div>
                           
                            <div class="item client-item">
								<a href="/tag/vtb/"><img src="<?php echo get_template_directory_uri();?>/images/bank/vtb.jpg" alt="возврат страховки втб"></a>
                            </div>
                            
                            <div class="item client-item">
                               <img src="<?php echo get_template_directory_uri();?>/images/bank/otk.jpg" alt="возврат страховки отк банка">
                            </div>
                            
                            <div class="item client-item">
                               <img src="<?php echo get_template_directory_uri();?>/images/bank/abb.jpg" alt="возврат страховки ак барс банка">
                            </div>
                            
                            <div class="item client-item">
								<a href="/tag/sber/"><img src="<?php echo get_template_directory_uri();?>/images/bank/sbr.jpg" alt="возврат страховки сбера"></a>
                            </div>
                            
                            <div class="item client-item">
                                <img src="<?php echo get_template_directory_uri();?>/images/bank/ren.jpg" alt="возврат страховки">
                            </div>
                            
                            <div class="item client-item">
                                <img src="<?php echo get_template_directory_uri();?>/images/bank/uralsib.jpg" alt="возврат страховки уралсиб">
                            </div>
                           
                            <div class="item client-item">
                                <img src="<?php echo get_template_directory_uri();?>/images/bank/mts.jpg" alt="возврат страховки мтс банка">
                            </div>
                            
                            <div class="item client-item">
                                <img src="<?php echo get_template_directory_uri();?>/images/bank/tin.jpg" alt="возврат страховки тинькоф банка">
                            </div>
                            
                            <div class="item client-item">
                                 <a href="/tag/sovkombank/"><img src="<?php echo get_template_directory_uri();?>/images/bank/skb.jpg" alt="возврат страховки совкомбанка"></a>
                            </div>
							
							<div class="item client-item">
								 <a href="/tag/alfabank/"><img src="<?php echo get_template_directory_uri();?>/images/bank/alf.jpg" alt="возврат страховки альфа банка"></a>
                            </div>
                            
                            <div class="item client-item">
                                <a href="/tag/psb/"><img src="<?php echo get_template_directory_uri();?>/images/bank/psb.jpg" alt="возврат страховки промсвязьбанка"></a>
                            </div>
                            
                            <div class="item client-item">
                               <img src="<?php echo get_template_directory_uri();?>/images/bank/pochta.jpg" alt="возврат страховки почта банка">
                            </div>
                            
                            <div class="item client-item">
								<a href="/tag/vtb/"><img src="<?php echo get_template_directory_uri();?>/images/bank/vtb.jpg" alt="возврат страховки втб"></a>
                            </div>
                            
                            <div class="item client-item">
                               <img src="<?php echo get_template_directory_uri();?>/images/bank/otk.jpg" alt="возврат страховки отк банка">
                            </div>
                            
                            <div class="item client-item">
                               <img src="<?php echo get_template_directory_uri();?>/images/bank/abb.jpg" alt="возврат страховки ак барс банка">
                            </div>
                            
                            <div class="item client-item">
								<a href="/tag/sber/"><img src="<?php echo get_template_directory_uri();?>/images/bank/sbr.jpg" alt="возврат страховки сбера"></a>
                            </div>
                            
                            <div class="item client-item">
                                <img src="<?php echo get_template_directory_uri();?>/images/bank/ren.jpg" alt="возврат страховки">
                            </div>
                            
                            <div class="item client-item">
                                <img src="<?php echo get_template_directory_uri();?>/images/bank/uralsib.jpg" alt="возврат страховки уралсиб">
                            </div>
                            
                            <div class="item client-item">
                                <img src="<?php echo get_template_directory_uri();?>/images/bank/mts.jpg" alt="возврат страховки мтс банка">
                            </div>
                            
                            <div class="item client-item">
                                <img src="<?php echo get_template_directory_uri();?>/images/bank/tin.jpg" alt="возврат страховки тинькоф банка">
                            </div>
                            
                            <div class="item client-item">
                                <a href="/tag/sovkombank/"><img src="<?php echo get_template_directory_uri();?>/images/bank/skb.jpg" alt="возврат страховки совкомбанка"></a>
                            </div>
                            
                            
                        </div>
                        
                        <div class="testimonial-customNavigation client-customNavigation">
                          <div class="btn client_prev"><i class="fa fa-long-arrow-left"></i></div>
                          <div class="btn client_next"><i class="fa fa-long-arrow-right"></i></div>
                        </div>
                        
                </div>
             
            </div>
        </div>     
    </section> 
<!-- БАНКИ -->