
<!-- ВОЗВРАТ -->
<section>
   <div class="col-xs-12 col-sm-10">
       <div class="Title-area">
           <h2>Возможности возврата</h2>
       </div>
   </div>
   
   <?php $my_posts = get_posts('numberposts=6&category=4&orderby=date'); foreach ($my_posts as $post) :setup_postdata($post); ?>
   
   <div class="col-sm-6 col-md-4 mt-50">
       <div class="home-5-p-c-content">
           <div class="home-5-p-c-details text-center">
              <h2><?php the_title(); ?></h2> 
               <hr>
               <p><?php the_field('small-opis'); ?></p>
               <hr>
   			<p><i class="fa fa-bars" aria-hidden="true"></i> <a href="<?php the_field('link'); ?>"> <?php the_field('link-name'); ?></a></p><hr>
               <p><a href="<?php the_field('baza'); ?>"><i class="fa fa-gavel" aria-hidden="true"></i> Правовая база</a></p><hr>
                <p><a href="<?php the_field('comment'); ?>"><i class="fa fa-comment" aria-hidden="true"></i> Правовой комментарий</a></p><hr>
   			<p>
   				<a href="/svyazki-bankov/"><i class="fa fa-exclamation-circle" aria-hidden="true"></i>Связки банков и доп.организаций, навязывающих услуги</a>
   			</p>
           </div>
       </div>
   </div>
   <?php wp_reset_postdata();?>
   <?php endforeach; ?>
</section>
<!-- ВОЗВРАТ -->