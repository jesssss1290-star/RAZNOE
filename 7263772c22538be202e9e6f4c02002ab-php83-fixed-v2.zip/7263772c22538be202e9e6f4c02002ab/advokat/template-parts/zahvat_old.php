    <!-- захват -->
    <section class="home-2-contact-us type-1-bg">
        <div class="home-2-right-bg"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="welcome-title-area">
                        <div class="Title-area">
                            <h3>Не стесняйтесь задавать вопросы</h3>
                            <h2>Закажите бесплатную консультацию</h2>
							<p>Наш специалист свяжется с Вами и проведет первичную консультацию. После чего Вы сможете или приехать в офис или направить документацию (кредитный договор, договор страхования, карты помощи и т.д.) в электронном формате для получения полного правового анализа и получения заключения касательно решения вашей задачи. Все вышеуказанные действия абсолютно бесплатные для клиента и ни к чему его не обязывают.</p>
							<p><strong>Мы работаем на результат, без предоплаты!</strong></p>
                        </div>
                    </div>                
                    <div class="contact-form home-2-contact-form">
                        <div class="show_result"></div>
                        <div class="result_message"></div>                           
                        <form>
                            <div class="row">
                                <div class="col-sm-6">
                                    <input type="text" class="form-control" id="Name" placeholder="Имя"> 
                                </div>
                                <div class="col-sm-6">
                                    <input type="email" class="form-control" id="Email" placeholder="EMAIL"> 
                                </div>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="Subject" placeholder="Тема"> 
                                </div>
                                <div class="col-sm-12">
                                    <textarea class="form-control" rows="3" id="Message" placeholder="Подробности"></textarea>
                                </div>
                                <div class="col-sm-12">
                                    <button type="button" id="contact_submit" class="btn btn-dm">Задайте свой вопрос</button>
                                </div>
                            </div>
                        </form>
                    </div>                        
                </div>
                <div class="col-md-6">
                    <div class="h-2-c-u-r-img">
                    </div>
                </div>
            </div>
        </div>
    </section> 
     <!-- /захват -->