
<!-- ОТЗЫВЫ -->
    <section class="contact-us home-3-contact-us">
        
        <div class="welcome-title-area">
            <div class="container">
                <div class="row">
                    <div class="col-xs-8 col-sm-6">
                        <div class="Title-area contact-title">
                            <span class="h3">Что о нас говорят?</span>
                            <h2>Отзывы <span class="hidden-xs">наших </span>клиентов</h2>
                        </div>
                    </div>
                    <div class="col-xs-4 col-sm-6">
                        <div class="asset-button btn-text-left text-right top-margin">
                            <button type="button" class="btn btn-default"><a href="/reviews/">Все отзывы <i class="fa fa-long-arrow-right hidden-xs"></i></a></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="contact-form">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div id="home-3-testimonial-demo" class="owl-carousel owl-theme">
                            <div class="item">
                                <div class="owl-testimonial-content home-3-testimonial-slider">
                                    <i class="fa fa-quote-left"></i>
                                    <img src="<?php echo get_template_directory_uri();?>/images/otziv/1.jpg" alt="">
                                </div>
                            </div>
                            <div class="item">
                                <div class="owl-testimonial-content home-3-testimonial-slider">
                                    <i class="fa fa-quote-left"></i>
                                    <img src="<?php echo get_template_directory_uri();?>/images/otziv/2.jpg" alt="">
                                </div>
                            </div> 
                            <div class="item">
                                <div class="owl-testimonial-content home-3-testimonial-slider">
                                    <i class="fa fa-quote-left"></i>
                                   <img src="<?php echo get_template_directory_uri();?>/images/otziv/4.jpg" alt="">                                 
                                </div>
                            </div>
                            <div class="item">
                                <div class="owl-testimonial-content home-3-testimonial-slider">
                                    <i class="fa fa-quote-left"></i>
                                   <img src="<?php echo get_template_directory_uri();?>/images/otziv/5.jpg" alt="">                                 
                                </div>
                            </div>
                            <div class="item">
                                <div class="owl-testimonial-content home-3-testimonial-slider">
                                    <i class="fa fa-quote-left"></i>
                                   <img src="<?php echo get_template_directory_uri();?>/images/otziv/6.jpg" alt="">                                 
                                </div>
                            </div>
                            <div class="item">
                                <div class="owl-testimonial-content home-3-testimonial-slider">
                                    <i class="fa fa-quote-left"></i>
                                   <img src="<?php echo get_template_directory_uri();?>/images/otziv/7.jpg" alt="">                                 
                                </div>
                            </div>
                            <div class="item">
                                <div class="owl-testimonial-content home-3-testimonial-slider">
                                    <i class="fa fa-quote-left"></i>
                                   <img src="<?php echo get_template_directory_uri();?>/images/otziv/8.jpg" alt="">                                 
                                </div>
                            </div>
                            <div class="item">
                                <div class="owl-testimonial-content home-3-testimonial-slider">
                                    <i class="fa fa-quote-left"></i>
                                   <img src="<?php echo get_template_directory_uri();?>/images/otziv/9.jpg" alt="">                                 
                                </div>
                            </div>
                            <div class="item">
                                <div class="owl-testimonial-content home-3-testimonial-slider">
                                    <i class="fa fa-quote-left"></i>
                                   <img src="<?php echo get_template_directory_uri();?>/images/otziv/10.jpg" alt="">                                 
                                </div>
                            </div>
                            <div class="item">
                                <div class="owl-testimonial-content home-3-testimonial-slider">
                                    <i class="fa fa-quote-left"></i>
                                   <img src="<?php echo get_template_directory_uri();?>/images/otziv/11.jpg" alt="">                                 
                                </div>
                            </div>
                            <div class="item">
                                <div class="owl-testimonial-content home-3-testimonial-slider">
                                    <i class="fa fa-quote-left"></i>
                                   <img src="<?php echo get_template_directory_uri();?>/images/otziv/12.jpg" alt="">                                 
                                </div>
                            </div>
                            <div class="item">
                                <div class="owl-testimonial-content home-3-testimonial-slider">
                                    <i class="fa fa-quote-left"></i>
                                   <img src="<?php echo get_template_directory_uri();?>/images/otziv/13.jpg" alt="">                                 
                                </div>
                            </div>
                        </div>                        
                    </div>                              
                </div>                
            </div>
        </div>
    </section> 
<!-- ОТЗЫВЫ -->