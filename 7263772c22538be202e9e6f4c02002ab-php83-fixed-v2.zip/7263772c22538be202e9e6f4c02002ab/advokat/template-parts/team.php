
<!-- КОМАНДА -->
<section class="practice-area h-7-practice-area h-7-custom-practice">
        
        <div class="welcome-title-area">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-10">
                        <div class="Title-area">
                            <span class="h3">Коллектив специалистов</span>
                            <h2>Наша команда</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
        
        <div class="container">
            <div class="row">
                <div class="col-md-12 no-padding blokk">
                        
                        <div id="home-7-practice-demo" class="owl-carousel owl-theme">
                             <?php $my_posts = get_posts('numberposts=30&category=3&orderby=date'); foreach ($my_posts as $post) :setup_postdata($post); ?>
                            <div class="item home-7-slider">
                                <a href="<?php the_permalink();?>"><img src="<?php if ( has_post_thumbnail()) { $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full'); echo $large_image_url[0]; } ?>"  alt="<?php the_title(); ?>"></a>
                                <div class="h-7-p-c-slider-hover">
                                    <h4><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h4>
                                    <span><?php the_field('doljnost'); ?></span>
                                    <p><?php the_field('sfera'); ?></p>
                                </div>                                
                            </div> 
                            <?php wp_reset_postdata();?>
                            <?php endforeach; ?>                           
                        </div>
                        
                        <div class="testimonial-customNavigation home-7-customNavigation">
                          <div class="btn prev"><i class="fa fa-long-arrow-left"></i></div>
                          <div class="btn next"><i class="fa fa-long-arrow-right"></i></div>
                        </div>                     
                </div>
            </div>
        </div>
    </section>
<!-- КОМАНДА -->