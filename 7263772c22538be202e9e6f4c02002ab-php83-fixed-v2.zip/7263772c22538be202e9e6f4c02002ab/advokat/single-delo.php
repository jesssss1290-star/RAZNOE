<?php
/*
 * Template Name: Выигранное Дело
 * Template Post Type: post
 */
?>

<?php get_header();?>

<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
   
   <!-- КОНТЕНТ -->
     <section class="testimonial-area home-2-testimonial-area">
        <div class="testimonial-content-area">
            <div class="container">
				<div class="row">
				   
				<!-- ОПРАВАЯ КОЛОНКА-->
				   <div class="col-sm-8 col-md-8">
					<div class="t-b-content-area blog-content-area clearfix">
                            
                            <!-- Контент -->
                            <div class="shop-review-content">  
                              <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                                <?php the_content(); ?>
                              <?php endwhile; ?><?php endif; ?>
                            <hr>
                            <!-- Контент -->
                            
                            
                            
                    <!-- ВОПРОСЫ И ОТВЕТЫ -->
                    
                    <p>Наша компания помогает клиентам вернуть средства, потраченные на навязанные услуги автодилеров, банков, страховых компаний и автосервисов. Множество наших клиентов уже успешно вернули свои деньги. Если у вас подобные проблемы — обращайтесь!</p>
                    
                       <div class="accordion-single-page">
                            <div class="clearfix">
                                <div class="single-accordion-content">
                                    <div class="faq-accordion">
                                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                            
                                            <!-- Вопрос -->  
                                            <div class="panel panel-default faq-content">
                                                <div class="panel-heading history-panel-heading" role="tab" id="heading2">
                                                  <h4 class="panel-title history-panel-title single-accordion-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse2" aria-expanded="false" aria-controls="collapse2"><i class="fa fa-question" aria-hidden="true"></i>Какова стоимость ваших услуг?</a>
                                                  </h4>
                                                </div>
                                                <div id="collapse2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading2">
                                                    <div class="panel-body history-panel-body faq-body">
                                                        <div class="faq-body-text">
                                                           <p>Мы не берём аванса за свои услуги. Мы самостоятельно проводим весь процесс взыскания – от досудебной стадии до судебного разбирательства. Оплата наших услуг происходит исключительно после успешного возврата средств на ваш счёт.</p> 
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Вопрос -->
                                            
                                            
                                             <!-- Вопрос -->  
                                            <div class="panel panel-default faq-content">
                                                <div class="panel-heading history-panel-heading" role="tab" id="heading1">
                                                  <h4 class="panel-title history-panel-title single-accordion-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="false" aria-controls="collapse1"><i class="fa fa-question" aria-hidden="true"></i>Какие сроки ведения дел?</a>
                                                  </h4>
                                                </div>
                                                <div id="collapse1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading1">
                                                    <div class="panel-body history-panel-body faq-body">
                                                        <div class="faq-body-text">
                                                            <p>Cроки ведения дела зависят от многих обстоятельств дела, примерный "сценарий" вы получите во время первой консультации. Более подробно этот вопрос описан на странице <a href="/czeny-i-sroki/">Цены и сроки.</a> Со своей стороны мы делаем всё возможное для ускорения процесса.</p>  
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Вопрос -->  
                                            
                                            
                                            <!-- Вопрос -->    
                                            <div class="panel panel-default faq-content">
                                                <div class="panel-heading history-panel-heading" role="tab" id="heading3">
                                                  <h4 class="panel-title history-panel-title single-accordion-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse3" aria-expanded="true" aria-controls="collapse3"><i class="fa fa-question" aria-hidden="true"></i>Возможно ли вернуть деньги без суда?</a>
                                                  </h4>
                                                </div>
                                                <div id="collapse3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3">
                                                    <div class="panel-body history-panel-body faq-body">
                                                        <div class="faq-body-text">
                                                              <p>Теоретически да. При обращении в течение 30 дней после оформления кредита, полный возврат средств за дополнительные услуги или страховку, включённую в кредит, возможен в досудебном порядке.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Вопрос -->  
                                            
                                            
                                            <!-- Вопрос -->  
                                            <div class="panel panel-default faq-content">
                                                <div class="panel-heading history-panel-heading" role="tab" id="heading4">
                                                  <h4 class="panel-title history-panel-title single-accordion-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse4" aria-expanded="false" aria-controls="collapse4"><i class="fa fa-question" aria-hidden="true"></i>Работаете ли вы с клиентами из других регионов?</a>
                                                  </h4>
                                                </div>
                                                <div id="collapse4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading4">
                                                    <div class="panel-body history-panel-body faq-body">
                                                        <div class="faq-body-text">
                                                             <p>Да мы работаем не только по Татарастану. Наша практика охватывает всю территорию России, мы регулярно выезжаем на суды в другие города и выигрываем!</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Вопрос -->  
                                            
                                            
                                            <!-- Вопрос -->  
											<div class="panel panel-default faq-content">
                                                <div class="panel-heading history-panel-heading" role="tab" id="heading5">
                                                  <h4 class="panel-title history-panel-title single-accordion-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse5" aria-expanded="false" aria-controls="collapse5"><i class="fa fa-question" aria-hidden="true"></i>Могу ли я сам вернуть свои деньги без юриста?</a>
                                                  </h4>
                                                </div>
                                                <div id="collapse5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading5">
                                                    <div class="panel-body history-panel-body faq-body">
                                                        <div class="faq-body-text">
                                                             <p>Компании, навязывающие дополнительные услуги, давно разработали стратегии отказа, апеллируя к договорным условиям и различным юридическим нюансам. Без профессионального юриста вы вряд ли сможете разговаривать с ними «на равных» и, скорее всего, ничего не вернёте.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Вопрос -->  
                                           
                                            
                                            <!-- Вопрос -->  
											<div class="panel panel-default faq-content">
                                                <div class="panel-heading history-panel-heading" role="tab" id="heading5">
                                                  <h4 class="panel-title history-panel-title single-accordion-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse5" aria-expanded="false" aria-controls="collapse5"><i class="fa fa-question" aria-hidden="true"></i>Какая общая схема работы с вашей компанией?</a>
                                                  </h4>
                                                </div>
                                                <div id="collapse5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading5">
                                                    <div class="panel-body history-panel-body faq-body">
                                                        <div class="faq-body-text">
                                                             <p>1. Свяжитесь с нами любым удобным способом (заявка на сайте, телефон, мессенджер). <br>
                                                                2. Вам позвонит юрист: уточнит обстоятельства дела и бесплатно проконсультирует.<br>
                                                                3. Вы один раз приезжаете к нам, подписываете договор и оставляете копии документов по делу.<br>
                                                                4. Все коммуникации с ответчиком и представительство в суде осуществляет наш специалист без вашего участия.<br>
                                                                5. По завершении дела вы получаете деньги на свой счёт и только потом оплачиваете наши услуги.</p><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Вопрос --> 
                                            

                                        </div>                            
                                    </div>                           
                                </div>   
                            </div>                          
                        </div>
                        <!-- ВОПРОСЫ И ОТВЕТЫ -->
                            
                            
                            
                            
							<!-- Юрист -->
							<div class="row kontur hidden-xs">		
											<div class="col-md-4 col-sm-4 col-xs-4">
                        								<div class="t-b-details t-b-single">
                                 							<div class="t-b-img">
                                          						<img src="https://provozvrat.ru/wp-content/uploads/2023/11/elvina.jpg"  alt="юрист">
                                  							</div>
                          								</div>
                   									</div>
												   <div class="col-md-8 col-sm-8 col-xs-8">
													    <div class="t-b-single">
															 <p class="h2">Автор статьи:<br><b>юрист Ахметова Эльвина Рустемовна</b></p>
															 <p>Сфера профессиональных навыков: гражданско-правовые споры, представление интересов в суде, защита прав потребителей, арбитраж и т.д.</p>
															 <div class="error-content feature-maintenance text-center">
                                                                    <a href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow">
                                                                    <i class="fa fa-phone" aria-hidden="true"></i> ЗАКАЗАТЬ ЗВОНОК</a>
                                                             </div>
														  </div>
												 </div>
								</div>
								<!-- Юрист -->
                            </div> 
                            <!-- Контент -->
                            
					   </div>
					</div>
					<!-- ОПРАВАЯ КОЛОНКА-->
					
					<!-- САЙДБАР -->
					<div class="col-md-4 col-sm-4 l-s-r-l-out">
					   <div class="right-sidebar">
						<div class="sidebar-category sidebar-inner">

						    <?php the_field('knopki_v_sajdbare'); ?>
                        
                        <h2 class="sbzag">Выигранные дела</h2>
						  <div class="row">
							    
                     	 <?php $my_posts = get_posts('numberposts=8&category=38&orderby=date'); foreach ($my_posts as $post) :setup_postdata($post); ?>
                                <div class="col-md-12 col-sm-12">
                                    <div class="t-b-single">
                                        <h4><a href="<?php the_permalink();?>"><i class="fa fa-balance-scale" aria-hidden="true"></i>&ensp;<?php the_title(); ?></a></h4>
                                        <p><?php kama_excerpt("maxchar=115"); ?> </p>
                                        <hr>
                                    </div>
                                </div>
                             	<?php wp_reset_postdata();?>
                              <?php endforeach; ?>
                              
                              <!-- Кнопка -->
                              	<div class="home-3-contact-details home-8-contact-details clearfix">
                                 <div class="no-padding-right">
                                    <div class="text-center">
                                       <a href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class=""><button type="button" class="btn btn-default button">Заказать консультацию</button></a>
                                    </div>
                                  </div>
                                </div>
                              <!-- Кнопка -->
                              
							</div> 
							</div>
						</div>
					</div>
					<!-- САЙДБАР -->
					
				</div>
               </div>     
           </div> 
    </section> 
    <!-- КОНТЕНТ -->
    
    <?php get_template_part( 'template-parts/zahvat2' ); ?>
    <?php get_template_part( 'template-parts/other' ); ?>
    
    <?php get_footer();?> 