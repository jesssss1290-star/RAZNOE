<?php get_header();?>
<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
    
    <section class="error-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="error-content text-center">
                        <h2>404</h2>
                        <p>Такой страницы не существует</p>
                        <a href="/">На главную</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php get_footer();?> 
