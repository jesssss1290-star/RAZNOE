<?php /* Template Name: Правовая база*/ get_header();?> 

<?php get_template_part( 'template-parts/breadcrumb-cat' ); ?>

     <section class="testimonial-area home-2-testimonial-area">
        <div class="testimonial-content-area">
            <div class="container">
                
                <!-- Выбод статей -->
                <div class="row">
                    <div class="t-b-content-area blog-content-area clearfix">
                        <div class="col-md-12 no-padding blog-custom-padding">
                            
                            <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                            <!-- карточка статьи -->
                            <div class="col-md-12 col-sm-12">
                                <div class="t-b-details t-b-single tb-grid row">
                                    <div class="col-md-2 hidden-xs">
                                         <img class="img-responsive" src="/wp-content/uploads/2025/03/vopros.jpg">
                                    </div>
                                    <div class="col-md-10">
									 <div class=" t-b-comment">
                                          <p><i class="fa fa-pencil-square" aria-hidden="true"></i> Опубликовано: <span><?php the_date('j F Y');?></span></p>
                                      </div>
                                      <h3><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h3>
                                      <p><?php kama_excerpt("maxchar=240"); ?> </p>
                                    </div>
                                </div>
                            </div>
                            <!-- карточка статьи -->
                            <?php endwhile; ?> 
                            <?php endif; ?>
					
                        </div>     
                    </div> 
                </div> 
				<!-- Выбод статей -->
				
				<style>.tb-grid {margin-bottom: 20px;min-height: 30px;}</style>
				
				<!-- Блок контента -->
				<div class="t-b-content-area blog-content-area clearfix">
                        <div class="no-padding">
                            <div class="t-b-details blog-tb-details">
                            
                            <?php echo category_description(); ?>
                            <!-- Пагинация -->
                            <div class="row">
                                <div class="col-md-12 blog-pagination text-center clearfix">
                                    <div class="pagination-wrapper">
                                            <?php
                                            if ( function_exists('wp_bootstrap_pagination') )
                                            wp_bootstrap_pagination();
                                            ?>
                                    </div>                                  
                                </div>
                            </div> 
                            <!-- Пагинация -->
						</div>
					</div>
				</div>
				<!-- Блок контента -->
			
            </div>        
        </div>        
    </section>
    
<?php get_footer();?> 