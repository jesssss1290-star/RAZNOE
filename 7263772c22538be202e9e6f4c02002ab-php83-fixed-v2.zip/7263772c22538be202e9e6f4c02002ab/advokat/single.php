    <?php
/*
 * Template Name: Базовая
 * Template Post Type: post
 */
?>
<?php get_header();?>
<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
    <section class="testimonial-area">
        <div class="testimonial-content-area">
            <div class="container">
                <div class="row">
                    <div class="t-b-content-area blog-content-area clearfix">                        
                        <div class="col-md-12 col-sm-12 no-padding blog-custom-padding">
                            <div class="col-md-12 col-sm-12">
                                <div class="t-b-details blog-tb-details blog-tb-single-details"> 
									<div class="t-b-img">
                                    <img src="<?php if ( has_post_thumbnail()) { $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full'); echo $large_image_url[0]; } ?>"  alt="">
                                    </div>
									
									<div class="t-b-comment">
                                    <p><i class="fa fa-pencil-square" aria-hidden="true"></i> Опубликовано: <span><?php the_date();?></span></p>
                                   
                                </div>
                                    <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                                    <?php the_content(); ?>
                                    <?php endwhile; ?><?php endif; ?>
                                </div>  
                            </div>    
                        </div>    
                    </div>
                </div>
            </div>       
        </div>       
    </section>
    <?php get_footer();?> 
