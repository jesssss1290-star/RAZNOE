<?php get_header();?>
<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
    <!-- страховые компании -->
    <section style="padding-top: 50px;" class="testimonial-area home-5-testimonial-area type-1-bg">
        <div class="testimonial-content-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="owl-testimonial-content h-5-owl-testimonial-content">
                            <i class="fa fa-star"></i>
                            <div class="Title-area">
                                <h3></h3>
                                <h2>Страховые компании</h2>
                            </div>
                            <p>Мы работаем со всеми страховыми компаниями<br>в Российской Федерации</p> 
                        </div>
                    </div>
                    <div class="col-md-6 no-padding-left">
                        <div id="home-5-testimonial-demo" class="owl-carousel owl-theme">
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                        <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/strah/kapital.jpg" alt=""></a>
                                    </div>
                                    <div class="home-5-t-s-img">
                                        <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/strah/alfa.jpg" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                        <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/strah/standart.jpg" alt=""></a>
                                    </div>
                                    <div class="home-5-t-s-img">
                                        <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/strah/card.jpg" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                        <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/strah/europa.jpg" alt=""></a>
                                    </div>
                                    <div class="home-5-t-s-img">
                                        <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/strah/sogaz.jpg" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                        <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/strah/rosgos.jpg" alt=""></a>
                                    </div>
                                    <div class="home-5-t-s-img">
                                        <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/strah/sber.jpg" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="home-5-testimonial-slider">
                                    <div class="home-5-t-s-img">
                                         <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/strah/reco.jpg" alt=""></a>
                                    </div>
                                    <div class="home-5-t-s-img">
                                         <a href="#"><img src="<?php echo get_template_directory_uri();?>/images/strah/ren.jpg" alt=""></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="testimonial-customNavigation home-5-customNavigation">
                          <a class="btn prev"><i class="fa fa-long-arrow-left"></i></a>
                          <a class="btn next"><i class="fa fa-long-arrow-right"></i></a>
                        </div>
                    </div>                    
                </div>
            </div>
        </div>       
    </section>
    <!-- страховые компании -->
    <section class="feature-typo h-f-typo"> 
        <div class="container"> 
            <div class="row">                 
                <div class="col-md-12">  
                    <div class="shop-single-review clearfix"> 
                        <div class="shop-review-content">  
                            <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                            <?php the_content(); ?>
                            <?php endwhile; ?><?php endif; ?>
                        </div>  
                    </div> 
										 
                </div> 
            </div> 
        </div>                       
    </section> 
<?php get_template_part( 'template-parts/zahvat2' ); ?>
<?php get_footer();?> 