<?php /* Template Name: Дела*/ get_header();?> 

<?php get_template_part( 'template-parts/breadcrumb-cat' ); ?>

     <section class="testimonial-area home-2-testimonial-area">
        <div class="testimonial-content-area">
            <div class="container">
                
                <!-- СТАТЬИ -->
                <div class="row dela">
                    <div class="t-b-content-area blog-content-area clearfix">
                        <div class="col-md-12 no-padding blog-custom-padding">
                            
                            <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                            
                            <!-- Статья -->
                            <div class="col-md-6 col-sm-6 row statiya">
                                    <div class="col-xs-3 kart">
                                         <a href="<?php the_permalink();?>"><img class="img-kat img-responsive" src="<?php if ( has_post_thumbnail()) { $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full'); echo $large_image_url[0]; } ?>"  alt="<?php the_title(); ?>"></a>
                                    </div>
                                    <div class="col-xs-9 text">
                                      <h4><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h4>
                                      <p><?php kama_excerpt("maxchar=119"); ?> </p>
                                    </div>
                            <hr class="hr-line">
                            </div>
                            
                            <!-- Статья -->
                            
                            <?php endwhile; ?> 
                            <?php endif; ?>
					
                        </div>     
                    </div> 
                </div> 
				<!-- СТАТЬИ -->
				
				<div class="t-b-content-area blog-content-area clearfix">
                        <div class="no-padding">
                            <div class="t-b-details blog-tb-details">
                            
                            <!-- Описание -->
                            <?php echo category_description(); ?>
                            
                            <!-- Пагинация -->
                            <div class="row">
                                <div class="col-md-12 blog-pagination text-center clearfix">
                                    <div class="pagination-wrapper">
                                            <?php
                                            if ( function_exists('wp_bootstrap_pagination') )
                                            wp_bootstrap_pagination();
                                            ?>
                                    </div>                                  
                                </div>
                            </div> 
                            <!-- Пагинация -->
                            
							</div>
						</div>
				</div>
				
			
            </div>        
        </div>        
    </section>
    
<?php get_footer();?> 