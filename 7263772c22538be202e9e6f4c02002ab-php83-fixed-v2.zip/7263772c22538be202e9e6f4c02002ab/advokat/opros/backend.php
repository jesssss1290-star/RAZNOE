<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// Resolve Composer from this plugin directory, independent of WordPress' CWD.
require_once __DIR__ . '/vendor/autoload.php';

new OprosBackend();

class OprosBackend {
	public $mail_list = 'provozvrat1@gmail.com, jesssss@yandex.ru, zakazz@provozvrat.ru, zakazprovozvrat.ru@mail.ru, advokat19181@yandex.ru';         // список e-mail, на которые придет заявка (через запятую)
	public $mail_theme = 'Клиент из опросника provozvrat.ru';         // тема письма

    public $from_email = 'wordpress@provozvrat.ru'; // email, с которого придет письма
    public $from_name = 'PRO.VOZVRAT';    // имя отправителя (название компании)

	public function __construct() {
		add_action( 'wp_ajax_opros', [$this, 'ajax_opros_callback']);
		add_action( 'wp_ajax_nopriv_opros', [$this, 'ajax_opros_callback']);
	}

	public function ajax_opros_callback() {

		header('Content-Type: application/json');

		$response_error = function () {
			echo json_encode(['status' => 'error']);
			wp_die(); // выход нужен для того, чтобы в ответе не было ничего лишнего, только то что возвращает функция
		};
		$response_ok = function ($payload = []) {
			echo json_encode(array_merge(['status' => 'ok'], $payload));
			wp_die();
		};


		if ($_SERVER['REQUEST_METHOD'] !== 'POST') $response_error();
		if (!isset($_FILES["data"]["tmp_name"])) $response_error();
		if ($_FILES["data"]["error"] !== 0) $response_error();

		try {
			$json = json_decode(file_get_contents($_FILES["data"]["tmp_name"]), false);
			if (!isset($json->name) || !isset($json->phone)) $response_error();

			$attach = null;
			if (isset($_FILES["attach"]["tmp_name"])) {
				if ($_FILES["attach"]["error"] !== 0) $response_error();
				$attach = $_FILES["attach"];
			}

			if ($this->sendMail($json, $attach)) {
				$response_ok();
			} else $response_error();

		} catch (Exception $e) {
			$response_error();
		}

	}

	public function sendMail($json, $attach) {
		$mail = new PHPMailer(true);

		try {
			//Recipients
			$mail->setFrom($this->from_email, $this->from_name); // from

			foreach (explode(',', $this->mail_list) as $email) {
				$email = trim($email);
				if ($email) $mail->addAddress($email);                                  // to
			}

			//Attachments
			if (is_array($attach)) {
				$mail->addAttachment($attach["tmp_name"], $attach["name"], PHPMailer::ENCODING_BASE64, $attach["type"]);
			}

			//Content
			$mail->isHTML(true);                                  //Set email format to HTML
			$mail->CharSet = PHPMailer::CHARSET_UTF8;
			$mail->Subject = $this->mail_theme;
			$mail->Body    = $this->getMailBody($json);

			// Send mail
			$mail->send();

			do_action('proref_form_sent'); // ПРО.РЕФЕРАЛ: засчитать заявку партнёру (если плагин выключен, ничего не происходит)

			return true;

		} catch (Exception $e) {

			return false;

		}
	}

	public function getMailBody($json) {
		ob_start(); ?>
		<p>Клиент из опросника provozvrat.ru</p>
		<table>
			<tr><td>Имя:</td><td><?=esc_html($json->name)?></td></tr>
			<tr><td>Телефон:</td><td><?=esc_html($json->phone)?></td></tr>
			<tr><td>E-mail:</td><td><?=esc_html($json->email)?></td></tr>
			<tr><td>Можете описать суть вопроса:</td><td><?=esc_html($json->text)?></td></tr>
			<?php // ПРО.РЕФЕРАЛ: если клиент пришёл по партнёрской ссылке, добавляются строки о реферере
			foreach ( apply_filters('proref_referral_lines', []) as $label => $value ) : ?>
			<tr><td><?=esc_html($label)?>:</td><td><?=esc_html($value)?></td></tr>
			<?php endforeach; ?>
		</table>
        <h2>Опрос:</h2>
        <ol>
        <?php foreach ( $json->questions as $q ) : ?>
            <li>
                <?=wp_filter_nohtml_kses($q->question)?>
                <div><b><?=wp_filter_nohtml_kses($q->answer)?></b></div>
            </li>
        <?php endforeach; ?>
        </ol>
        <div><b><?=wp_filter_nohtml_kses($json->msg)?></b></div>
		<?php return ob_get_clean();
	}
}



