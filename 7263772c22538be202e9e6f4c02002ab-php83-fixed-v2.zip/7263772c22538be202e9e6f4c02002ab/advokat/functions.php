<?php
add_filter('widget_tag_cloud_args','set_tag_cloud_args');
function set_tag_cloud_args( $args ) {
	$args['number'] = 250;
	return $args;
}

// Колонка миниатюры в списке записей админки  
 
add_filter('manage_posts_columns', 'posts_columns', 5);  
add_action('manage_posts_custom_column', 'posts_custom_columns', 5, 2);    
function posts_columns($defaults){      $defaults['riv_post_thumbs'] = __('Миниатюра');      return $defaults;  }    
function posts_custom_columns($column_name, $id){  	if($column_name === 'riv_post_thumbs'){          the_post_thumbnail( array(50, 50) );      }  }

// Отключить экранирование тегов <script> и <iframe> в версиях acf начиная с 6.2.5
add_filter( 'acf/the_field/allow_unsafe_html', '__return_true'); // в функции the_field()
add_filter( 'acf/shortcode/allow_unsafe_html', '__return_true'); // в шоркоде [acf field="field_name"]


// Отключить экранирование тегов <script> и <iframe> в версиях acf начиная с 6.2.5
add_filter( 'acf/the_field/allow_unsafe_html', '__return_true'); // в функции the_field()
add_filter( 'acf/shortcode/allow_unsafe_html', '__return_true'); // в шоркоде [acf field="field_name"]

/**Проблемы ОПРОСНИК**/
add_filter('script_loader_tag', function ($tag, $handle, $src) {
    if ($handle !== 'oprosnik') {
        return $tag;
    }
    return sprintf(
        '<script type="module" src="%s" id="oprosnik-js"></script>' . "\n",
        esc_url($src)
    );
}, 10, 3);
/**Проблемы ОПРОСНИК**/

/**Проблемы маршрутизации**/
function del_number_url_morkovin(){
$link = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
$matches = array();
preg_match("/^(.+)\/([0-9]+)$/", $link, $matches);
if(is_single() && !empty($matches[2]))
{global $wp_query;$wp_query->set_404();status_header(404);}}
add_action('wp', 'del_number_url_morkovin', -10);


/** Удаляем мусор из хеда**/
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');
remove_action( 'wp_head', 'wp_shortlink_wp_head');
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head');
remove_action( 'wp_head', 'feed_links_extra', 3);
remove_action( 'wp_head', 'feed_links', 2 );
remove_action('wp_head','rel_canonical');

  
/**Поддержка миниатюр**/
add_theme_support('post-thumbnails');
set_post_thumbnail_size(150,125);

function my_register_sidebars() {
/* регистрация правого сайдбара */
 register_sidebar(
 array(
 'id' => 'right-side', // уникальный id для сайта, назначается правому сайдбару
 'name' => 'Правая колонка', // название сайдбара, которое будет отображаться в админке
 'description' => 'Перетяните виджеты, чтобы добавить их в сайдбар.', // описание выводимое в админке для сайдбара
 'before_widget' => '<div class="r-sidebar">', // по умолчанию виджеты выводятся <li>-списком
 'after_widget' => '</div>', // в этой и предыдущей строке мы задали контейнер в котором будет размещен сайдбар
 'before_title' => '<h3 class="r-wtitle">', // если оставить пустым, будет выводиться в <h2>
 'after_title' => '</h3>'
 )
 );
 
/* регистрация левого сайдбара */
 register_sidebar(
 array(
 'id' => 'left-side', // уникальный id для сайта, назначается правому сайдбару
 'name' => 'Левая колонка', // название сайдбара, которое будет отображаться в админке
 'description' => 'Перетяните виджеты, чтобы добавить их в сайдбар.', // описание выводимое в админке для сайдбара
 'before_widget' => '<div class="l-sidebar">', // по умолчанию виджеты выводятся <li>-списком
 'after_widget' => '</div>', // в этой и предыдущей строке мы задали контейнер в котором будет размещен сайдбар
 'before_title' => '<h3 class="l-wtitle">', // если оставить пустым, будет выводиться в <h2>
 'after_title' => '</h3>'
 )
 );
/* регистрация сайдбара для футера */
 register_sidebar(
 array(
 'id' => 'menu-side', // уникальный id для сайта, назначается правому сайдбару
 'name' => 'Основное меню', // название сайдбара, которое будет отображаться в админке
 'description' => 'Перетяните виджеты, чтобы добавить их в сайдбар.', // описание выводимое в админке для сайдбара
 'before_widget' => '<div class="f-sidebar">', // по умолчанию виджеты выводятся <li>-списком
 'after_widget' => '</div>', // в этой и предыдущей строке мы задали контейнер в котором будет размещен сайдбар
 'before_title' => '<h3 class="f-wtitle">', // если оставить пустым, будет выводиться в <h2>
 'after_title' => '</h3>'
 )
 );
/* регистрация сайдбара для рубрик */
 register_sidebar(
 array(
 'id' => 'rubric', // уникальный id для сайта, назначается правому сайдбару
 'name' => 'Рубрики', // название сайдбара, которое будет отображаться в админке
 'description' => 'Перетяните виджеты, чтобы добавить их в сайдбар.', // описание выводимое в админке для сайдбара
 'before_widget' => '<div class="f-sidebar">', // по умолчанию виджеты выводятся <li>-списком
 'after_widget' => '</div>', // в этой и предыдущей строке мы задали контейнер в котором будет размещен сайдбар
 'before_title' => '<h3 class="f-wtitle">', // если оставить пустым, будет выводиться в <h2>
 'after_title' => '</h3>'
 )
 );
}
 
add_action( 'widgets_init', 'my_register_sidebars' );


register_nav_menus(array(
	'top'    => 'Верхнее меню',    //Название месторасположения меню в шаблоне
	'bottom' => 'Нижнее меню'      //Название другого месторасположения меню в шаблоне
));

/**Обрезка анонса до 20 слов**/
function new_excerpt_length($length) {
	return 20;
}
add_filter('excerpt_length', 'new_excerpt_length');

/** Меняем [...]', '...'**/

function new_excerpt_more($more) {
	return '...';
}
add_filter('excerpt_more', 'new_excerpt_more');


/**
 * Обрезка текста (excerpt). Шоткоды вырезаются. Минимальное значение maxchar может быть 22.
 * version 2.1
 *
 * maxchar     - количество символов.
 * text        - какой текст обрезать (по умолчанию берется excerpt поста, если его нету, то content, если есть тег <!--more-->, то maxchar игнорируется и берется все, что до <!--more--> как есть (с HTML)
 * save_format - Сохранять перенос строк или нет. По умолчанию сохраняется. Если в параметр указать определенные теги, то они НЕ будут вырезаться из обрезанного текста (пример: save_format=<strong><a> )
 * echo        - выводить на экран или возвращать (return) для обработки.
 *
 * @param (строка) $args - аргументы в строке.
 *
 * @return HTML
*/
function kama_excerpt( $args = '' ){
	global $post;
	
	$default = array( 'maxchar' => 350, 'text' => '', 'save_format' => false, 'more_text' => 'Читать дальше...', 'echo' => true, );
	
	parse_str( $args, $_args );
	$args = array_merge( $default, $_args );
	extract( $args );
		
	if( ! $text ){
		$text = $post->post_excerpt ? $post->post_excerpt : $post->post_content;
		
		$text = preg_replace ('~\[[^\]]+\]~', '', $text ); // убираем шоткоды, например:[singlepic id=3]
	    // $text = strip_shortcodes( $text ); // или можно так обрезать шоткоды, так будет вырезан шоткод и конструкция текста внутри него
	    // и только те шоткоды которые зарегистрированы в WordPress. И эта операция быстрая, но она в десятки раз дольше предыдущей 
	    // (хотя там очень маленькие цифры в пределах одной секунды на 50000 повторений)
		
		// для тега <!--more-->
		if( ! $post->post_excerpt && strpos( $post->post_content, '<!--more-->') ){
			preg_match ('~(.*)<!--more-->~s', $text, $match );
			$text = trim( $match[1] );
			$text = str_replace("\r", '', $text );
			$text = preg_replace( "~\n\n+~s", "</p><p>", $text );
			$text = '<p>'. str_replace( "\n", '<br />', $text ) .' <a href="'. get_permalink( $post->ID ) .'#more-'. $post->ID .'">'. $more_text .'</a></p>';
			
			if( $echo ) return print $text;
			
			return $text;
		}
		elseif( ! $post->post_excerpt )
			$text = strip_tags( $text, $save_format );
	}	
	
	// Обрезаем
	if ( mb_strlen( $text ) > $maxchar ){
		$text = mb_substr( $text, 0, $maxchar );
		$text = preg_replace('@(.*)\s[^\s]*$@s', '\\1 ...', $text ); // убираем последнее слово, оно 99% неполное
	}
	
	// Сохраняем переносы строк. Упрощенный аналог wpautop()
	if( $save_format ){
		$text = str_replace("\r", '', $text );
		$text = preg_replace("~\n\n+~", "</p><p>", $text );
		$text = "<p>". str_replace ("\n", "<br />", trim( $text ) ) ."</p>";
	}
	
	//$out = preg_replace('@\*[a-z0-9-_]{0,15}\*@', '', $out); // удалить *some_name-1* - фильтр сммайлов
	
	if( $echo ) return print $text;
	
	return $text;
}




	/* Убиваем хрень в хедере
---------------------------------------------------------- */


    remove_action( 'wp_head', 'adjacent_posts_rel_link', 10, 0 ); // Удаляет ссылки на предыдущую и следующую статьи
    remove_action( 'wp_head', 'index_rel_link'); // Удаляет ссылку на главную страницу 
    remove_action( 'wp_head', 'parent_post_rel_link', 10, 0 ); // Удаляет ссылку на родительскую страницу 
    remove_action( 'wp_head', 'start_post_rel_link', 10, 0 ); // Удаляет ссылку на первую запись
	



/**
 Пагинация бутстрап
 */
function bootstrap_paginate_links_data( $links, $args ) {
	$navigation = '';

	if ( is_array( $links ) && $links ) {
		$pagination = '<ul class="pagination pagination-sm flex-wrap justify-content-center">';

		foreach ( $links as $link ) {
			$active   = strpos( $link, 'current' );
			$disabled = strpos( $link, 'dots' );
			$link     = str_replace( 'page-numbers', 'page-numbers page-link', $link );

			if ( $active == true ) {
				$pagination .= "<li class=\"page-item active\">$link</li>";
			} elseif ( $disabled == true ) {
				$pagination .= "<li class=\"page-item disabled\">$link</li>";
			} else {
				$pagination .= "<li class=\"page-item\">$link</li>";
			}
		}
		$pagination .= '</ul>';
		$navigation  = _navigation_markup( $pagination, 'pagination-nav', $args['screen_reader_text'] );
	}

	return $navigation;
}


function get_the_bootstrap_pagination() {
	global $wp_query;
	$navigation = '';
	$big        = 999999999; // need an unlikely integer

	$args =  array(
		'base'               => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
		'format'             => '?paged=%#%',
		'current'            => max( 1, get_query_var( 'paged' ) ),
		'total'              => $wp_query->max_num_pages,
		'screen_reader_text' => false,
		'end_size'           => 1,
		'mid_size'           => 3,
		'prev_text'          => '&laquo;',
		'next_text'          => '&raquo;',
		'type'               => 'array',
	);

	// Set up paginated links.
	$links      = paginate_links( $args );
	$navigation = bootstrap_paginate_links_data( $links, $args );

	return $navigation;
}

function the_clean_pagination()
{
 $thePagination = get_the_bootstrap_pagination();

 echo preg_replace('~(<h2\\s(class="screen-reader-text")(.*)[$>])(.*)(</h2>)~ui', '', $thePagination);
}


/**
 Пагинация бутстрап
 */

	
/* 
 * Хлебные крошки для WordPress (breadcrumbs)
 *
 * $sep  - разделитель. По умолчанию ' » '
 * $l10n - массив. для локализации. См. переменную $default_l10n.
 * $args - массив. дополнительные аргументы.
 * version 0.51
*/
function kama_breadcrumbs( $sep = 0, $l10n = array(), $args = array() ){
	global $post, $wp_query, $wp_post_types;

	// Локализация
	$default_l10n = array(
		'home'       => 'Главная',
		'paged'      => 'Страница %s',
		'_404'       => 'Ошибка 404',
		'search'     => 'Результаты поиска по запросу - <b>%s</b>',
		'author'     => 'Архив автора: <b>%s</b>',
		'year'       => 'Архив за <b>%s</b> год',
		'month'      => 'Архив за: <b>%s</b>',
		'day'        => '',
		'attachment' => 'Медиа: %s',
		'tag'        => 'Записи по метке: <b>%s</b>',
		'tax_tag'    => '%s из "%s" по тегу: <b>%s</b>',
	);
	
	// Параметры по умолчанию
	$default_args = array(
		'on_front_page'   => true, // выводить крошки на главной странице
		'show_post_title' => true, // показывать ли название записи в конце (последний элемент). Для записей, страниц, вложений
		'sep'             => ' » ', // разделитель
	);
	
	// Фильтрует аргументы по умолчанию.
	$default_args = apply_filters('kama_breadcrumbs_default_args', $default_args );
	
	$loc  = (object) array_merge( $default_l10n, $l10n );
	$args = (object) array_merge( $default_args, $args );

	if( $sep === 0 ) $sep = $args->sep;

	$w1 = '<div class="kama_breadcrumbs" prefix="v: http://rdf.data-vocabulary.org/#">';
	$w2 = '</div>';
	$patt1 = '<span typeof="v:Breadcrumb"><a href="%s" rel="v:url" property="v:title">';
	$sep .= '</span>'; // закрываем span после разделителя!
	$linkpatt = $patt1.'%s</a>';
	
	
	// Вывод
	$pg_end = '';
	if( $paged = $wp_query->query_vars['paged'] ){
		$pg_patt = $patt1;
		$pg_end = '</a>'. $sep . sprintf( $loc->paged, $paged );
	}

	$out = '';
	if( is_front_page() ){
		return $args->on_front_page ? ( print $w1 .( $paged ? sprintf( $pg_patt, home_url() ) : '' ) . $loc->home . $pg_end . $w2 ) : '';
	}
	elseif( is_404() ){
		$out = $loc->_404; 
	}
	elseif( is_search() ){
		$out = sprintf( $loc->search, strip_tags( $GLOBALS['s'] ) );
	}
	elseif( is_author() ){
		$q_obj = &$wp_query->queried_object;
		$out = ( $paged ? sprintf( $pg_patt, get_author_posts_url( $q_obj->ID, $q_obj->user_nicename ) ):'') . sprintf( $loc->author, $q_obj->display_name ) . $pg_end;
	}
	elseif( is_year() || is_month() || is_day() ){
		$y_url  = get_year_link( $year=get_the_time('Y') );
		$m_url  = get_month_link( $year, get_the_time('m') );
		$y_link = sprintf( $linkpatt, $y_url, $year);
		$m_link = sprintf( $linkpatt, $m_url, get_the_time('F'));
		if( is_year() )
			$out = ( $paged?sprintf( $pg_patt, $y_url):'') . sprintf( $loc->year, $year ) . $pg_end;
		elseif( is_month() )
			$out = $y_link . $sep . ( $paged ? sprintf( $pg_patt, $m_url ) : '') . sprintf( $loc->month, get_the_time('F') ) . $pg_end;
		elseif( is_day() )
			$out = $y_link . $sep . $m_link . $sep . get_the_time('l');
	}

	// Страницы и древовидные типы записей
	elseif( is_singular() && $wp_post_types[ $post->post_type ]->hierarchical ){
		$parent = $post->post_parent;
		$crumbs = array();
		while( $parent ){
			$page = & get_post( $parent );
			$crumbs[] = sprintf( $linkpatt, get_permalink( $page->ID ), $page->post_title );
			$parent = $page->post_parent;
		}
		$crumbs = array_reverse( $crumbs );
		
		foreach( $crumbs as $crumb ) $out .= $crumb . $sep;
		
		$out = $out . ( $args->show_post_title ? $post->post_title : '');
	}
	// Таксономии, вложения и не древовидные типы записей
	else
	{
		// Определяем термины
		if( is_singular() ){
			$taxonomies = get_taxonomies( array('hierarchical' => true, 'public' => true) );
			if( count( $taxonomies ) == 1 ) $taxonomies = 'category';
			
			if( $term = get_the_terms( $post->post_parent ? $post->post_parent : $post->ID, $taxonomies ) ){
				$term = array_shift( $term );
			}
		}
		else
			$term = $wp_query->get_queried_object();
		

		//if( ! $term && ! is_attachment() ) return print "Error: Taxonomy is not defined!"; 
		
		if( $term ){
			$term = apply_filters('kama_breadcrumbs_term', $term );
			
			$pg_term_start = ( $paged && $term->term_id ) ? sprintf( $pg_patt, get_term_link( (int) $term->term_id, $term->taxonomy ) ) : '';

			if( is_attachment() ){
				if( ! $post->post_parent )
					$out = sprintf( $loc->attachment, $post->post_title );
				else
					$out = __crumbs_tax( $term->term_id, $term->taxonomy, $sep, $linkpatt ) . sprintf( $linkpatt, get_permalink( $post->post_parent ), get_the_title( $post->post_parent ) ) . $sep . ( $args->show_post_title ? $post->post_title : '');
			}
			elseif( is_single() ){
				$out = __crumbs_tax( $term->parent, $term->taxonomy, $sep, $linkpatt ) . sprintf( $linkpatt, get_term_link( (int) $term->term_id, $term->taxonomy ), $term->name ). $sep . ( $args->show_post_title ? $post->post_title : '');
			// Метки, архивная страница типа записи, произвольные одноуровневые таксономии
			}
			elseif( ! is_taxonomy_hierarchical( $term->taxonomy ) ){
				// метка
				if( is_tag() )
					$out = $pg_term_start . sprintf( $loc->tag, $term->name ) . $pg_end;
				// таксономия
				elseif( is_tax() ){
					$post_label = $wp_post_types[ $post->post_type ]->labels->name;
					$tax_label = $GLOBALS['wp_taxonomies'][ $term->taxonomy ]->labels->name;
					$out = $pg_term_start . sprintf( $loc->tax_tag, $post_label, $tax_label, $term->name ) .  $pg_end;
				}
			}
			// Рубрики и таксономии
			else
				$out = __crumbs_tax( $term->parent, $term->taxonomy, $sep, $linkpatt ) . $pg_term_start . $term->name . $pg_end;
		}
	}

	// замена ссылки на архивную страницу для типа записи 
	$home_after = apply_filters('kama_breadcrumbs_home_after', false, $linkpatt, $sep );

	// ссылка на архивную страницу произвольно типа поста. Ссылку можно заменить с помощью хука 'kama_breadcrumbs_home_after'
	if( ! $home_after && isset( $post->post_type ) && ! in_array( $post->post_type, array('post','page','attachment') ) ){
		$pt_name = $wp_post_types[ $post->post_type ]->labels->name;
		$pt_url  = get_post_type_archive_link( $post->post_type );
		$home_after = ( is_post_type_archive() && ! $paged ) ? $pt_name : ( sprintf( $linkpatt, $pt_url, $pt_name ). ($pg_end?$pg_end:$sep) );
	}

	
	$home = sprintf( $linkpatt, home_url(), $loc->home ). $sep . $home_after;
	
	$out = $w1. $home . $out .$w2;

	return print apply_filters('kama_breadcrumbs', $out, $sep );
}
function __crumbs_tax( $term_id, $tax, $sep, $linkpatt ){
	$termlink = array();
	while( (int) $term_id ){
		$term2      = get_term( $term_id, $tax );
		$termlink[] = sprintf( $linkpatt, get_term_link( (int) $term2->term_id, $term2->taxonomy ), $term2->name ). $sep;
		$term_id    = (int) $term2->parent;
	}
	
	$termlinks = array_reverse( $termlink );
	
	return implode('', $termlinks );
}


// Вывод разного количества постов в рубриках
function custom_posts_per_page($query){
    if(is_search()){
        $query->set('posts_per_page',-1);
    }
   if (is_category('tovary')){
        $query->set('posts_per_page',24);
}
   if (is_category('portfolio')){
        $query->set('posts_per_page',80);
}
}
// Вывод разного количества постов в рубриках


// Превью нужного размера
add_action( 'after_setup_theme', function () {

// Эти размеры есть "из коробки"

//	thumbnail (uses the size 150px × 150px)
//	medium (uses the size 300px × 300px)
//	medium_large (uses the size 768px × 0px)
//	large (uses the size 1024px × 1024px)


// Добавляем свой размер
add_image_size('gall', 600, 600, true);
add_image_size('gall2', 600, 600);
add_image_size('usluga', 800, 500, true);
// вместо 'mh-size' придумываем имя
// вместо 500, 200 указываем нужные размеры
// true - вырезать из середины (не масштабировать).	Если на указать - будет масштабароваться.

} );
// Превью нужного размера

/**
 * WordPress Bootstrap Pagination
 */

function wp_bootstrap_pagination( $args = array() ) {
    
    $defaults = array(
        'range'           => 4,
        'custom_query'    => FALSE,
        'previous_string' => __( '<', 'text-domain' ),
        'next_string'     => __( '>', 'text-domain' ),
        'before_output'   => '<div class="post-nav"><ul class="pager">',
        'after_output'    => '</ul></div>'
    );
    
    $args = wp_parse_args( 
        $args, 
        apply_filters( 'wp_bootstrap_pagination_defaults', $defaults )
    );
    
    $args['range'] = (int) $args['range'] - 1;
    if ( !$args['custom_query'] )
        $args['custom_query'] = @$GLOBALS['wp_query'];
    $count = (int) $args['custom_query']->max_num_pages;
    $page  = intval( get_query_var( 'paged' ) );
    $ceil  = ceil( $args['range'] / 2 );
    
    if ( $count <= 1 )
        return FALSE;
    
    if ( !$page )
        $page = 1;
    
    if ( $count > $args['range'] ) {
        if ( $page <= $args['range'] ) {
            $min = 1;
            $max = $args['range'] + 1;
        } elseif ( $page >= ($count - $ceil) ) {
            $min = $count - $args['range'];
            $max = $count;
        } elseif ( $page >= $args['range'] && $page < ($count - $ceil) ) {
            $min = $page - $ceil;
            $max = $page + $ceil;
        }
    } else {
        $min = 1;
        $max = $count;
    }
    
    $echo = '';
    $previous = intval($page) - 1;
    $previous = esc_attr( get_pagenum_link($previous) );
    
    $firstpage = esc_attr( get_pagenum_link(1) );
    if ( $firstpage && (1 != $page) )
        $echo .= '<li class="previous"><a href="' . $firstpage . '">' . __( 'Первая', 'text-domain' ) . '</a></li>';

    if ( $previous && (1 != $page) )
        $echo .= '<li><a href="' . $previous . '" title="' . __( 'previous', 'text-domain') . '">' . $args['previous_string'] . '</a></li>';
    
    if ( !empty($min) && !empty($max) ) {
        for( $i = $min; $i <= $max; $i++ ) {
            if ($page == $i) {
                $echo .= '<li class="active"><span class="active">' . str_pad( (int)$i, 2, '0', STR_PAD_LEFT ) . '</span></li>';
            } else {
                $echo .= sprintf( '<li><a href="%s">%002d</a></li>', esc_attr( get_pagenum_link($i) ), $i );
            }
        }
    }
    
    $next = intval($page) + 1;
    $next = esc_attr( get_pagenum_link($next) );
    if ($next && ($count != $page) )
        $echo .= '<li><a href="' . $next . '" title="' . __( 'next', 'text-domain') . '">' . $args['next_string'] . '</a></li>';
    
    $lastpage = esc_attr( get_pagenum_link($count) );
    if ( $lastpage ) {
        $echo .= '<li class="next"><a href="' . $lastpage . '">' . __( 'Последняя', 'text-domain' ) . '</a></li>';
    }

    if ( isset($echo) )
        echo $args['before_output'] . $echo . $args['after_output'];
}

// WordPress may load functions.php with a different current working
// directory. Resolve the plugin backend from the theme directory.
require_once __DIR__ . '/opros/backend.php';

/**
 * WordPress Bootstrap Pagination
 */
 
 
 
 /**
 * Использование в статье:
 *   [zayavka]
 *   [zayavka text="Остались вопросы? Оставьте" link="заявку на консультацию"]
 */

add_shortcode( 'zayavka', 'my_zayavka_shortcode' );

function my_zayavka_shortcode( $atts ) {
	$atts = shortcode_atts( array(
		'text' => 'оставьте',
		'link' => 'заявку',
	), $atts, 'zayavka' );

	// Модальное окно выводим в подвал сайта и только один раз,
	// даже если шорткод встречается на странице несколько раз.
	static $modal_added = false;
	if ( ! $modal_added ) {
		add_action( 'wp_footer', 'my_zayavka_modal' );
		$modal_added = true;
	}

	ob_start();
	?>
	
<div class="zayavka">
	<svg class="zayavka__icon" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
	<div class="zayavka__body">
		<p class="zayavka__title">Не можете разобраться в своём случае?</p>
		<p class="zayavka__text">Не понимаете, реально ли отказаться от договора и вернуть свои деньги? Не знаете с чего начать? Пришлите фото кредитного договора, страховки или договора на доп.услугу. Юрист компании PRO.VOZVRAT проанализирует ваши документы и подскажет, что делать конкретно в вашем случае.</p>
		<p class="zayavka__action">
			<a href="#" class="zayavka__btn" data-toggle="modal" data-target="#ModalOrderPackage02" rel="nofollow">Отправить документы юристу</a>
			<br><span class="zayavka__note">Бесплатно и ни к чему не обязывает</span>
		</p>
	</div>
</div>	
	
	
	<?php
	return ob_get_clean();
}

function my_zayavka_modal() {
	?>
	<!--noindex-->
	<div class="modal fade fform" id="ModalOrderPackage02" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-sm" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Закрыть">
						<span class="icon-cancel"><i class="fa fa-times"></i></span>
					</button>
				</div>
				<div class="forma">
					<?php echo do_shortcode( '[contact-form-7 id="06523fc" title="Вопрос по ситуации"]' ); ?>
				</div>
			</div>
		</div>
	</div>
	<!--/noindex-->
	<script>document.addEventListener( 'wpcf7mailsent', function( event ) {jQuery('#formvopr2').hide(); }, false );</script>
	<script>
	document.addEventListener( 'wpcf7mailsent', function () {
		setTimeout( function () {
			jQuery( '#ModalOrderPackage02' ).modal( 'hide' );
		}, 4000 );
	}, false );
	</script>
	<?php
}

 
