<?php
/*
 * Template Name: Инструкция НОВАЯ
 * Template Post Type: post
 */
?>

<?php get_header();?>

<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
   
   <!-- КОНТЕНТ -->
     <section class="testimonial-area home-2-testimonial-area">
        <div class="testimonial-content-area">
            <div class="container">
				<div class="row">
				   
				<!-- ОПРАВАЯ КОЛОНКА-->
				   <div class="col-sm-8 col-md-8">
					<div class="t-b-content-area blog-content-area clearfix">
                            
                            <!-- Контент -->
                            
                            <div class="shop-review-content">  
                              <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                                <?php the_content(); ?>
                              <?php endwhile; ?><?php endif; ?>
                            <hr>
                            
							<!-- Юрист -->
							<div class="row kontur hidden-xs">		
											<div class="col-md-4 col-sm-4 col-xs-4">
                        								<div class="t-b-details t-b-single">
                                 							<div class="t-b-img">
                                          						<img src="<?php the_field('img'); ?>"  alt="юрист">
                                  							</div>
                          								</div>
                   									</div>
												   <div class="col-md-8 col-sm-8 col-xs-8">
													    <div class="t-b-single">
															 <p class="h2">Автор статьи:<br><b>юрист <?php the_field('fio'); ?></b></p>
															 <p><?php the_field('sfera'); ?></p>
															 <div class="error-content feature-maintenance text-center">
                                                                    <a href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow">
                                                                    <i class="fa fa-phone" aria-hidden="true"></i> ЗАКАЗАТЬ ЗВОНОК</a>
                                                             </div>
														  </div>
												 </div>
								</div>
								<!-- Юрист -->
                            </div> 
                            <!-- Контент -->
                            
					   </div>
					</div>
					<!-- ПРАВАЯ КОЛОНКА-->
					
					<!-- САЙДБАР -->
					<div class="col-md-4 col-sm-4 l-s-r-l-out">
					   <div class="right-sidebar">
						<div class="sidebar-category sidebar-inner">

						    <?php the_field('knopki_v_sajdbare'); ?>
                        
                        <h2 class="sbzag">Выигранные дела</h2>
						  <div class="row">
							    
                     	 <?php $my_posts = get_posts('numberposts=8&category=38&orderby=date'); foreach ($my_posts as $post) :setup_postdata($post); ?>
                                <div class="col-md-12 col-sm-12">
                                    <div class="t-b-single">
                                        <h4><a href="<?php the_permalink();?>"><i class="fa fa-balance-scale" aria-hidden="true"></i>&ensp;<?php the_title(); ?></a></h4>
                                        <p><?php kama_excerpt("maxchar=115"); ?> </p>
                                        <hr>
                                    </div>
                                </div>
                             	<?php wp_reset_postdata();?>
                              <?php endforeach; ?>
                              
                              <!-- Кнопка -->
                              	<div class="home-3-contact-details home-8-contact-details clearfix">
                                 <div class="no-padding-right">
                                    <div class="text-center">
                                       <a href="" data-toggle="modal" data-target="#ModalOrderPackage01" rel="nofollow" class=""><button type="button" class="btn btn-default button">Заказать консультацию</button></a>
                                    </div>
                                  </div>
                                </div>
                              <!-- Кнопка -->
                              
							</div> 
							</div>
						</div>
					</div>
					<!-- САЙДБАР -->
					
				</div>
               </div>     
           </div> 
    </section> 
    <!-- КОНТЕНТ -->
    
    <?php get_template_part( 'template-parts/zahvat2' ); ?>
    <?php get_template_part( 'template-parts/other' ); ?>
    
    <?php get_footer();?> 